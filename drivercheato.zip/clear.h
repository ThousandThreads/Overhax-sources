#pragma once
#include <ntddk.h>
#include <windef.h>
#define POOLTAG 'vRf5'
