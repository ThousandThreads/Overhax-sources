#pragma once
#define PI 3.1415927f

int GetDistance(float Xx, float Yy, float Zz, float xX, float yY, float zZ)
{
	Vector3 Distance;
	Distance.x = Xx - xX;
	Distance.y = Yy - yY;
	Distance.z = Zz - zZ;

	return sqrtf((Distance.x * Distance.x) + (Distance.y * Distance.y) + (Distance.z * Distance.z));
}

float FGetDistance(float Xx, float Yy, float Zz, float xX, float yY, float zZ)
{
	Vector3 Distance;
	Distance.x = Xx - xX;
	Distance.y = Yy - yY;
	Distance.z = Zz - zZ;

	return sqrtf((Distance.x * Distance.x) + (Distance.y * Distance.y) + (Distance.z * Distance.z));
}

float CalculateDistance(Vector3 _Position1, Vector3 _Position2) {
	return sqrt((_Position1.x - _Position2.x) * (_Position1.x - _Position2.x) +
		(_Position1.y - _Position2.y) * (_Position1.y - _Position2.y) +
		(_Position1.z - _Position2.z) * (_Position1.z - _Position2.z));
}

void NormalizeAngles(QAngle& angle)
{
	while (angle.x > 89.0f)
		angle.x -= 180.f;

	while (angle.x < -89.0f)
		angle.x += 180.f;

	while (angle.y > 180.f)
		angle.y -= 360.f;

	while (angle.y < -180.f)
		angle.y += 360.f;
}

QAngle CalcAngle(const Vector& src, const Vector3& dst)
{
	QAngle angle = QAngle();
	SVector delta = SVector((src.x - dst.x), (src.y - dst.y), (src.z - dst.z));

	double hyp = sqrt(delta.x*delta.x + delta.y * delta.y);

	angle.x = atan(delta.z / hyp) * (180.0f / M_PI);
	angle.y = atan(delta.y / delta.x) * (180.0f / M_PI);
	angle.z = 0;
	if (delta.x >= 0.0) angle.y += 180.0f;

	return angle;
}

double GetFov(const QAngle& viewAngle, const QAngle& aimAngle)
{
	QAngle delta = aimAngle - viewAngle;
	NormalizeAngles(delta);

	return sqrt(pow(delta.x, 2.0f) + pow(delta.y, 2.0f));
}


std::string ItemsNameList[] = { "",
"Kraber",
"Mastiff",
"Lstar",
"Havoc",
"Gold Havoc",
"Devotion",
"Triple Take",
"Unknown 1",
"VK-47",
"Gold Triple Take",
"Hemlock",
"G7 Scout",
"Hemlock",
"Alternator",
"Gold G7 Scout",
"Alternator",
"Prowler",
"R-99",
"Longbow",
"Gold Prowler",
"Charge Rifle",
"Gold Longbow",
"Spitfire",
"R-301",
"Spitfire",
"R-301",
"Peacekeeper",
"Peacekeeper",
"Unknown 3",
"Mozambique",
"Gold Peacekeeper",
"Mozambique",
"Gold Mozambique",
"P2020",
"Gold Wingman",
"P2020",
"Gold P2020",
"Sentinel",
"Gold RE-45",

"Light Ammo",
"Energy Ammo",
"Shotgun Ammo",
"Heavy Ammo",
"Sniper Ammo",

"Ultimate Accelerant",
"Phoenix Kit",
"Med Kit",
"Seringle",
"Shield Battery",
"Shield Cell",

"Helmet 1",
"Helmet 2",
"Helmet 3",
"Helmet 4",

"Shield 1",
"Shield 2",
"Shield 3",
"Shield 4",

"KO Shield 1",
"KO Shield 2",
"KO Shield 3",
"KO Shield 4",

"Backpack 1",
"Backpack 2",
"Backpack 3",
"Backpack 4",

"Thermite Grenade",
"Frag Grenade",
"Shuriken",

"HCOG Classic",
"HCOG Bruiser",
"Holo",
"Variable Holo",
"Digital Threat",
"HCOG Ranger",
"Variable AOG",
"Sniper 6x",
"Variable Sniper",
"Digital Sniper Threat",

"Barrel Stab 1",
"Barrel Stab 2",
"Barrel Stab 3",
"Barrel Stab 4",

"Light Mag 1",
"Light Mag 2",
"Light Mag 3",

"Heavy Mag 1",
"Heavy Mag 2",
"Heavy Mag 3",

"Energy Mag 1",
"Energy Mag 2",
"Energy Mag 3",

"Shotgun Bolt 1",
"Shotgun Bolt 2",
"Shotgun Bolt 3",

"Standard Stock 1",
"Standard Stock 2",
"Standard Stock 3",

"Sniper Stock 1",
"Sniper Stock 2",
"Sniper Stock 3",

"Turbocharger",
"Selectfire Receiver",
"Choke",
"Hammerpoint Rounds",
 };

class Item
{
public:
	uint64_t base;
	Vector3 Origin;
	Vector3 Screen;
	int Id;
	float distance;
};
Item ItemCache1[8000];
Item ItemCache2[100];

Vector3 GetEntityBasePosition(DWORD64 Entity)
{
	return read<Vector3>(Entity + OFFSET_ORIGIN);
}
Vector getPosition() {
	DWORD64 LocalPlayer = GetLocalPlayer();
	return read<Vector>(LocalPlayer + OFFSET_ORIGIN);
}
Vector3 GetBodyById(DWORD64 Entity, int bone) {
	Vector3 EntityPosition = GetEntityBasePosition(Entity);

	uint64_t boneClass = read<uint64_t>(Entity + OFFSET_BONES);

	return {
		read<float>((boneClass + 0xCC + bone * 0x30)) + EntityPosition.x,
		read<float>((boneClass + 0xDC + bone * 0x30)) + EntityPosition.y,
		read<float>((boneClass + 0xEC + bone * 0x30)) + EntityPosition.z
	};
}

struct Bone {
	BYTE shit[0xCC];
	float x;
	BYTE shit2[0xC];
	float y;
	BYTE shit3[0xC];
	float z;
};

Vector getBonePosition(DWORD_PTR entity, int id) {
	Vector position = getPosition();
	uintptr_t boneArray = read<uintptr_t>(entity + OFFSET_BONES);
	Vector bone = Vector();
	uint32_t boneloc = (id * 0x30);
	Bone bo = {};
	bo = read<Bone>(boneArray + boneloc);
	bone.x = bo.x + position.x;
	bone.y = bo.y + position.y;
	bone.z = bo.z + position.z;
	return bone;
}

Vector3 GetViewAngles(uintptr_t ent)
{
	return read<Vector3>(ent + OFFSET_VIEWANGLES);
}

void SetViewAngles(DWORD_PTR ptr, SVector angles)
{
	write<SVector>(ptr + OFFSET_VIEWANGLES, angles);
}
void SetViewAngles2(DWORD_PTR ptr, QAngle& angles)
{
	SetViewAngles(ptr, SVector(angles));
}

//void SetViewAngles(uintptr_t ent, Vector3 angles)
//{
//	write<Vector3>(ent + OFFSET_VIEWANGLES, angles);
//}

Vector3 GetCamPos(uintptr_t ent)
{
	return read<Vector3>(ent + OFFSET_CAMERAPOS);
}

bool world2screen(Vector3 position, Vector3& out)
{
	Vector3 vTransformed;

	DWORD64 viewrender = read<DWORD64>(baseAddress + OFFSET_VIEWRENDER);
	DWORD64 matrix = read<DWORD64>(viewrender + OFFSET_VIEWMATRIX);
	D3DMATRIX viewMatrix = read<D3DMATRIX>(matrix);

	vTransformed.x = (float)(position.y * viewMatrix.m[0][1]) + (float)(position.x * viewMatrix.m[0][0]) + (float)(position.z * viewMatrix.m[0][2]) + viewMatrix.m[0][3];
	vTransformed.y = (float)(position.y * viewMatrix.m[1][1]) + (float)(position.x * viewMatrix.m[1][0]) + (float)(position.z * viewMatrix.m[1][2]) + viewMatrix.m[1][3];
	vTransformed.z = (float)(position.y * viewMatrix.m[3][1]) + (float)(position.x * viewMatrix.m[3][0]) + (float)(position.z * viewMatrix.m[3][2]) + viewMatrix.m[3][3];

	if (vTransformed.z < 0.001)
		return false;

	vTransformed.x *= 1.0 / vTransformed.z;
	vTransformed.y *= 1.0 / vTransformed.z;

	const int width = Width;
	const int height = Height;

	out.x = width / 2.0f + vTransformed.x * (width / 2.0f);
	out.y = height / 2.0f - vTransformed.y * (height / 2.0f);

	return true;
}