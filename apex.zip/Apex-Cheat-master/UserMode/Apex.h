#include "xor.hpp"
BOOL GameisOpen()
{
	//hwnd = NULL;
	//while (hwnd == NULL) {
	//	hwnd = FindWindowA(0, _xor_("Apex Legends").c_str());
	//}

	m_driver_control = kernel_control_function();

	if (!m_driver_control)   //Checks If Driver Is Mapped To Complete Activating Cheat Features
		return false;

	PID = GetProcessID(XorString("r5apex.exe"));//iChecks If The Game Is Even Open When Activating Cheat Features.

	if (!PID)
		return false;

	//ShowWindow(GetConsoleWindow(), SW_HIDE);

	baseAddress = call_driver_control(
		m_driver_control, ID_GET_PROCESS_BASE, PID);

	if (baseAddress == NULL) {
		return false;
	}

	EntityList = read<DWORD64>(baseAddress + OFFSET_ENTITY);

	if (EntityList == NULL) {
		return false;
	}

	LocalPlayer = read<DWORD64>(baseAddress + OFFSET_LOCALPLAYER);

	if (LocalPlayer == NULL) {
		return false;
	}

	return true;
}

bool IsInGame = read<bool>(OFFSET_ISINGAME);
DWORD64 GetEntityByID(int Entity) {

	DWORD64 EntityList = baseAddress + OFFSET_ENTITY;

	return read<DWORD64>(EntityList + (Entity << 5));
}

bool IsInGamexd() {
	return read<bool>(0x1804240);
}

DWORD64 GetEntityHandle(DWORD64 Entity) {
	return read<DWORD64>(Entity + 0x518);
}

DWORD64 GetEntityName(DWORD64 EntityHandle) {
	return read<DWORD64>(EntityHandle);
}

DWORD64 GetLocalPlayer() {
	return read<DWORD64>(baseAddress + OFFSET_LOCALPLAYER);
}

DWORD64 GetLocalWeapon() {
	DWORD64 LocalPlayer = read<DWORD64>(baseAddress + OFFSET_LOCALPLAYER);
	DWORD64 Weapon = read<DWORD64>(LocalPlayer + OFFSET_LAST_WEAPON) & 0xFFFF;

	return read<DWORD64>(Weapon);
}

//Vector3 GetViewAngles()
//{
//	DWORD64 LocalPlayer = GetLocalPlayer();
//	return read<Vector3>(LocalPlayer + OFFSET_VIEWANGLES);
//}

QAngle GetViewAngles()
{
	DWORD64 LocalPlayer = GetLocalPlayer();
	return read<QAngle>(LocalPlayer + OFFSET_VIEWANGLES);
}

Vector GetCamPos()
{
	DWORD64 LocalPlayer = GetLocalPlayer();
	return read<Vector>(LocalPlayer + OFFSET_CAMERAPOS);
}

BOOL IsSameTeam(DWORD64 Entity)
{
	DWORD64 LocalPlayer = read<DWORD64>(baseAddress + OFFSET_LOCALPLAYER);
	DWORD myTeamId = read<DWORD>(LocalPlayer + OFFSET_TEAM);
	DWORD entityTeamNum = read<DWORD>(Entity + OFFSET_TEAM);

	if (myTeamId == entityTeamNum)
		return TRUE;

	return FALSE;
}

void __fastcall NoSpread()
{
	DWORD64 Weapon = GetLocalWeapon();

	write<float>(Weapon + 0x1370, 0.0000f);
	write<float>(Weapon + 0x1380, 0.0000f);
}

DWORD64 getLocalPlayer() {
	DWORD64 LocalPlayer = read<DWORD64>(baseAddress + OFFSET_LOCALPLAYER);
	return read<DWORD64>(LocalPlayer);
}

VOID GlowEsp(DWORD64 Entity, float r, float g, float b)
{
	//Enable Glow
	write<bool>(Entity + 0x390, true);
	write<int>(Entity + 0x310, 1);

	//Setting Color

	//write<float>(Entity + 0x1C8 + 0x8, r);
	//write<float>(Entity + 0x1CC + 0x8, g);
	//write<float>(Entity + 0x1D0 + 0x8, b);
	write<Vector3>(Entity + 0x1D0, Vector3(r, g, b));

	//Glow Time Max
	for (auto offset = 0x2D0; offset <= 0x2E8; offset += 0x4)
		write<float>(Entity + offset, FLT_MAX);

	//Distance Max
	write<float>(Entity + 0x2FC, FLT_MAX);
}

VOID DisableEsp(DWORD64 Entity)
{
	//Enable Glow
	write<bool>(Entity + 0x388 + 0x8, false);
	write<int>(Entity + 0x308 + 0x8, 0);

	write<float>(Entity + 0x1C8 + 0x8, 0.f);
	write<float>(Entity + 0x1CC + 0x8, 0.f);
	write<float>(Entity + 0x1D0 + 0x8, 0.f);
	//Glow Time Max
	for (auto offset = 0x2C8 + 0x8; offset <= 0x2E0 + 0x8; offset += 0x4 + 0x8)
		write<float>(Entity + offset, 0);
}

VOID glowItem(DWORD64 Entity, float r, float g, float b) //glow/chams 
{

	float color[3] = { 120.0f, 120.0f, 0 };

	write(Entity + 0x390, true);        //(EntityHandle + 0x380, true, 1);

	//Set Time
	write(Entity + 0x2FC, FLT_MAX);    //(EntityHandle + 0x2EC, FLT_MAX, 4);
	//Set Distance
	write(Entity + 0x2D4, FLT_MAX);    //(EntityHandle + 0x2C4, FLT_MAX, 4);

	//Color
	write(Entity + 0x1B0, r);     //(EntityHandle + 0x1A8, processID, 120.0f, 4 * 3);
	write(Entity + 0x1B4, g);
	write(Entity + 0x1B8, b);

	write(Entity + 0x278, 0x4D407D7E);
}

Vec2 OldAimPunch{};
void NoRecoil() {
	Vec2 AimPunch;
	Vec2 CurrView;
	Vec2 NewView;
	DWORD64 LocalEntity = read<DWORD64>(baseAddress + OFFSET_LOCALPLAYER);

	AimPunch = read<Vec2>(LocalEntity + OFFSET_AIMPUNCH);


	CurrView = read<Vec2>(LocalEntity + OFFSET_VIEWANGLES);

	NewView.x = (CurrView.x + OldAimPunch.x) - AimPunch.x; //pitch
	NewView.y = (CurrView.y + OldAimPunch.y) - AimPunch.y; //yaw

	write<Vec2>(LocalEntity + OFFSET_VIEWANGLES, NewView);

	OldAimPunch = AimPunch;
}

Vector3 GetFeetPos(DWORD64 Entity) {
	if (!Entity)
		return Vector3{ 0,0,0 };

	Vector3 pos = read<Vector3>(Entity + 0x2154);

	return pos;
}

Vector3 GetHeadPos(DWORD64 Entity) {
	if (!Entity)
		return Vector3{ 0,0,0 };

	Vector3 pos = read<Vector3>(Entity + 0x3E58);
	return pos;
}

std::string GetEntityNames(DWORD_PTR entity) {
	DWORD64 EntityHandle = read<DWORD64>(entity + 0x518);
	DWORD64 EntityName = read<DWORD64>(EntityHandle);

	if (!EntityHandle)
		return "";

	return read_string<std::string>(EntityHandle);
}

std::string GetPlayerName(DWORD_PTR entity) {
	DWORD64 NameList = read<DWORD_PTR>(entity + 0x3a18);

	if (!NameList)
		return "";

	return read_string<std::string>(NameList);
}

std::string GetItemsName(DWORD_PTR entity) {
	DWORD_PTR NameList = read<DWORD_PTR>(entity + OFFSET_ITEMID);

	if (!NameList)
		return "";

	return read_string<std::string>(NameList);
}