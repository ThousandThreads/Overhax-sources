
uintptr_t cache;
bool bad_ptr(uintptr_t ptr)
{
	static auto minimum_application_address = uintptr_t(0x10000);
	static auto maximum_application_address = uintptr_t(0xFFE00000);
	return ((ptr >= minimum_application_address || ptr < maximum_application_address) || !ptr);
}
//command codes basically the value of the command codes
enum E_COMMAND_CODE
{
	ID_NULL = 0,	//

	ID_READ_PROCESS_MEMORY = 5,	// 
	ID_WRITE_PROCESS_MEMORY = 6,	//

	ID_READ_KERNEL_MEMORY = 8,	// 

	ID_GET_PROCESS = 10,	//
	ID_GET_PROCESS_BASE = 11,	//
	ID_GET_PROCESS_MODULE = 12,	//

	ID_SET_PAGE_PROTECTION = 26,  //

	ID_REMOVE_HOOK = 99,	//

	ID_CONFIRM_DRIVER_LOADED = 100,	//
};


//Holds the data for pid and other stuff
#pragma pack( push, 8 )
typedef struct _MEMORY_STRUCT
{
	UINT_PTR	process_id;
	PVOID		address;
	SIZE_T		size;
	SIZE_T		size_copied;
	PVOID		buffer;
} MEMORY_STRUCT, * PMEMORY_STRUCT;
#pragma pack( pop )


#pragma pack( push, 8 )
typedef struct _MEMORY_STRUCT_PROTECTION
{
	UINT_PTR	process_id;
	PVOID		address;
	SIZE_T		size;
	ULONG		protection;
	ULONG		protection_old;
} MEMORY_STRUCT_PROTECTION, * PMEMORY_STRUCT_PROTECTION;
#pragma pack( pop )

//contacts the driver and requests read or write
template<typename ... A>
uint64_t call_driver_control(void* control_function, const A ... arguments)
{
	if (!control_function)
		return 0;

	using tFunction = uint64_t(__stdcall*)(A...);//What The Fuck??
	const auto control = static_cast<tFunction>(control_function);

	return control(arguments ...);
}

//first contact with the driver
void* kernel_control_function()
{
	HMODULE hModule = LoadLibrary(XorString("win32u.dll"));

	if (!hModule)
		return nullptr;

	return reinterpret_cast<void*>(GetProcAddress(hModule, XorString("NtUserGetPrecisionTouchPadConfiguration")));
}

//Reads Kernel memory
uint64_t read_kernel(void* control_function, uint64_t address, void* buffer, std::size_t size)
{
	return call_driver_control(control_function, ID_READ_KERNEL_MEMORY, address, buffer, size);
}

//Closes Handles
struct HandleDisposer
{
	using pointer = HANDLE;
	void operator()(HANDLE handle) const
	{
		if (handle != NULL || handle != INVALID_HANDLE_VALUE)
		{
			CloseHandle(handle);
		}
	}
};

using unique_handle = std::unique_ptr<HANDLE, HandleDisposer>;


//Gets Process ID
static std::uint32_t GetProcessID(std::string process_name) {
	PROCESSENTRY32 processentry;
	const unique_handle snapshot_handle(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0));

	if (snapshot_handle.get() == INVALID_HANDLE_VALUE)
		return 0;

	processentry.dwSize = sizeof(MODULEENTRY32);

	while (Process32Next(snapshot_handle.get(), &processentry) == TRUE) {
		if (process_name.compare(processentry.szExeFile) == 0)
			return processentry.th32ProcessID;
	}
	return 0;
}

void* m_driver_control;
DWORD64 PID;
uintptr_t baseAddress;
uintptr_t game_manager;
uintptr_t status_manager;
uintptr_t camera_manager;
uintptr_t round_manager;
HWND hwnd;

int Width = GetSystemMetrics(SM_CXSCREEN);
int Height = GetSystemMetrics(SM_CYSCREEN);


//I guess it is used to change protection or something
NTSTATUS change_protection(void* ctrl, uint64_t pid, uint64_t address, uint32_t page_protection, std::size_t size)
{
	MEMORY_STRUCT_PROTECTION protection = { 0 };
	protection.process_id = pid;
	protection.address = reinterpret_cast<void*>(address);
	protection.size = size;
	protection.protection = page_protection;

	return (NTSTATUS)(call_driver_control(ctrl, ID_SET_PAGE_PROTECTION, &protection));
}


//Reads memory through driver
template<typename T>
__declspec(noinline) T read(uint64_t address)
{
	T buffer{};

	if (!PID)
		return buffer;

	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.process_id = PID;
	memory_struct.address = reinterpret_cast<void*>(address);
	memory_struct.size = sizeof(T);
	memory_struct.buffer = &buffer;

	NTSTATUS result
		= (NTSTATUS)(call_driver_control(m_driver_control, ID_READ_PROCESS_MEMORY, &memory_struct));

	if (result != 0)
		return buffer;

	return buffer;
}


//Writes memory through driver
template<typename T>
__declspec(noinline) bool write(uint64_t address, T buffer)
{
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.process_id = PID;
	memory_struct.address = reinterpret_cast<void*>(address);
	memory_struct.size = sizeof(T);
	memory_struct.buffer = &buffer;

	NTSTATUS result
		= (NTSTATUS)(call_driver_control(m_driver_control, ID_WRITE_PROCESS_MEMORY, &memory_struct));

	if (result != 0)
		return false;

	return true;
}

//writes process memory
bool WriteVirtual(uint64_t address, void* buffer, size_t size)
{
	MEMORY_STRUCT memory_struct = { 0 };
	memory_struct.process_id = PID;
	memory_struct.address = reinterpret_cast<void*>(address);
	memory_struct.size = size;
	memory_struct.buffer = buffer;

	uint64_t result = call_driver_control(m_driver_control, ID_WRITE_PROCESS_MEMORY, &memory_struct);

	if (result != 0)
		return false;

	return true;
}

template<typename T>

//Reades Process Memory
std::string read_string(uint64_t address)
{
	char buffer[100];

	if (!PID)
		MEMORY_STRUCT memory_stru			return buffer;
	ct = { 0 };
	memory_struct.process_id = PID;
	memory_struct.address = reinterpret_cast<void*>(address);
	memory_struct.size = sizeof(T);
	memory_struct.buffer = &buffer;

	NTSTATUS result
		= (NTSTATUS)(call_driver_control(m_driver_control, ID_READ_PROCESS_MEMORY, &memory_struct));

	if (result != 0)
		return "";

	std::string nameString;
	for (int i = 0; i < 100; i++) {
		if (buffer[i] == 0)
			break;
		else
			nameString += buffer[i];
	};

	return nameString;
}
