void Aimbot(float x, float y)
{
	float TargetX = 0;
	float TargetY = 0;

	int ScreenCenterX = (Width / 2);
	int ScreenCenterY = (Height / 2);

	float AimSpeed = Globals::Aimbot::AimSpeed;

	if (x != 0)
	{
		if (x > ScreenCenterX)
		{
			TargetX = -(ScreenCenterX - x);
			TargetX /= AimSpeed;
			if (TargetX + ScreenCenterX > ScreenCenterX * 2) TargetX = 0;
		}

		if (x < ScreenCenterX)
		{
			TargetX = x - ScreenCenterX;
			TargetX /= AimSpeed;
			if (TargetX + ScreenCenterX < 0) TargetX = 0;
		}
	}

	if (y != 0)
	{
		if (y > ScreenCenterY)
		{
			TargetY = -(ScreenCenterY - y);
			TargetY /= AimSpeed;
			if (TargetY + ScreenCenterY > ScreenCenterY * 2) TargetY = 0;
		}

		if (y < ScreenCenterY)
		{
			TargetY = y - ScreenCenterY;
			TargetY /= AimSpeed;
			if (TargetY + ScreenCenterY < 0) TargetY = 0;
		}
	}

	if (!Globals::Aimbot::smooth) {
		mouse_event(MOUSEEVENTF_MOVE, static_cast<DWORD>(TargetX), static_cast<DWORD>(TargetY), NULL, NULL);
		return;
	}

	TargetX /= 10;
	TargetY /= 10;

	if (fabs(TargetX) < 1)
	{
		if (TargetX > 0)
		{
			TargetX = 1;
		}
		if (TargetX < 0)
		{
			TargetX = -1;
		}
	}
	if (fabs(TargetY) < 1)
	{
		if (TargetY > 0)
		{
			TargetY = 1;
		}
		if (TargetY < 0)
		{
			TargetY = -1;
		}
	}
	mouse_event(MOUSEEVENTF_MOVE, TargetX, TargetY, NULL, NULL);

	return;
}
float DistanceBetweenCross(float X, float Y)
{
	float ydist = (Y - (Height / 2));
	float xdist = (X - (Width / 2));
	float Hypotenuse = sqrt(pow(ydist, 2) + pow(xdist, 2));
	return Hypotenuse;
}
bool GetAimKey()
{
	return (GetAsyncKeyState(Globals::Aimbot::HotKey));
}
bool GetClosestPlayerToCrossHair(Vector3 Pos, float& max, float aimfov, DWORD_PTR entity)
{
	if (!GetAimKey())
	{
		if (entity)
		{
			float min = FLT_MAX;

			Vector3 HeadPosition = GetBodyById(entity, Globals::Aimbot::AimHitbox);
			Vector3 ScreenFeet, ScreenHead;

			if (world2screen(HeadPosition, ScreenHead))
			{
				float Dist = DistanceBetweenCross(ScreenHead.x, ScreenHead.y);
				if (Dist < max)
				{
					max = Dist;
					Globals::Aimbot::AimFOV = aimfov;
					entityx = entity;
				}
			}
		}
	}
	return false;
}


void AimAt(DWORD_PTR entity)
{

	float min = FLT_MAX;

	if (Globals::Aimbot::aimbot)
	{
		Vector3 LocalPosition = GetEntityBasePosition(entity);
		Vector3 MyLocalPosition = GetEntityBasePosition(GetLocalPlayer());
		Vector3 HeadPosition = GetBodyById(entity, Globals::Aimbot::AimHitbox);
		Vector3 ScreenFeet, ScreenHead;

		if (world2screen(HeadPosition, ScreenHead))
		{
			if (ScreenHead.y != 0 || ScreenHead.x != 0)
			{
				if ((DistanceBetweenCross(ScreenHead.x, ScreenHead.y) <= Globals::Aimbot::AimFOV * 8) || isaimbotting)
				{
					Aimbot(ScreenHead.x, ScreenHead.y);
				}
			}
		}
	}
}
void DoAimbot()
{
	if (entityx != 0)
	{

		if (GetAimKey())
		{
			AimAt(entityx);
		}
		else
		{
			isaimbotting = false;
		}

	}
}

void AimLoop(DWORD_PTR entity)
{
	float max = 100.f;

	Vector3 LocalPosition = GetEntityBasePosition(entity);
	Vector3 HeadPosition = GetBodyById(entity, Globals::Aimbot::AimHitbox);

	GetClosestPlayerToCrossHair(HeadPosition, max, Globals::Aimbot::AimFOV, entity);
}
