
#ifndef OFFSETS_H
#define OFFSETS_H

#include <windows.h>


#define OFFSET_VIEWMATRIX                      0x1b3bd0 //season 5
#define OFFSET_VIEWRENDER                      0x3f3aad8//season 5

#define OFFSET_ENTITY                          0x175dc28 //entity list  season 5
#define OFFSET_LOCAL                           0x1dea658 //update
#define OFFSET_LOCALPLAYER                     0x175dc28//season 5
#define OFFSET_ORIGIN                          0x14C   //season 5     
#define OFFSET_ENTITY_POSITION_OFFSET          0x12C 
#define OFFSET_BONES                           0xED8  //season 5   
#define OFFSET_CAMERAPOS                       0x1DA4//season 5
#define OFFSET_CAMERAANGLE                     0x23D0
#define OFFSET_AIMPUNCH                        0x2300//season 5
#define OFFSET_VIEWANGLES                      0x23C8//season 5  
#define OFFSET_DYNAMICANGLE                    0x23C0//
#define OFFSET_ISINGAME                        0x111c190    //season 5
#define OFFSET_BLEED                           0x2588//season 5
#define OFFSET_ENTITY_ORIGIN                   0x014c //0x144 AbsVecOrgin Season 5

#define OFFSET_SCRIPTID                        0x1308     // 
#define OFFSET_BULLET_GRAVITY                  0x1D50     //season 5
#define OFFSET_ENTITY_VELOCITY                 0x420      //season 5
#define OFFSET_LAST_WEAPON                     0x1944     //  season 5 
#define OFFSET_HEALTH                          0x3E0        //season 5
#define OFFSET_SHIELD                          0x170   //season5     
#define OFFSET_TEAM                            0x3F0 //season 5      
#define OFFSET_ENTITY_NAME                     0x521  
#define OFFSET_ITEMID                          0x1548//season 5

#define OFFSET_ENTITY_ID                       0x8

#define LOCAL_PLAYER_PITCH                     0x2188//
#define LOCAL_PLAYER_YAW                       0x2188 + 4//

#ifdef _AMD64_
#define _PTR_MAX_VALUE ( 0x000F000000000000 )
#else 
#define _PTR_MAX_VALUE ( 0xFFE00000 )
#endif

inline bool _VALID(UINT_PTR Ptr)
{
	return (Ptr >= 0x10000) && (Ptr < _PTR_MAX_VALUE);
}

#endif

DWORD64 Entity_perf1 = NULL;
DWORD64 EntityList;
DWORD64 LocalPlayer;
DWORD64 LocalPlayer1;

bool unlocks = false;

bool aimboting;
bool isaimbotting;

int Color2DR = 170;
int Color2DG = 0;
int Color2DB = 240;

DWORD_PTR entityx;
int realaimkey = 0;
DWORD realkey;
