#include "main.h"

static const char* targetMode[] =
{
	"Disabled",
	"FOV",
	"Distance"
};

static const char* healthMode[] =
{
	"Disabled",
	"Left Bar",
	"Text",
	"LBar + Text"
};

static const char* shieldMode[] =
{
	"Disabled",
	"Right Bar",
	"Text",
	"RBar + Text"
};

static const char* boxStyle[] =
{
	"Disabled",
	"2D Box",
	"Corner Box"
};

static const char* glowStyle[] =
{
	"Disabled",
	"Enemy",
	"Items",
	"Enemy + Items"
};

static const char* nameMode[] =
{
	"Disabled",
	"Player",
	"Distance",
	"Dist + Player"
};

static const char* hotkeys[]
{ 
	"Mouse 5",
	"Mouse 4", 
	"Right Button", 
	"Left Button", 
	"Left Alt" 
};

static const char* Bones[]
{
	"Head",
	"Chest",
	"Neck"
};


void shortcurts()
{
	switch (realaimkey)
	{
	case 0:
		Globals::Aimbot::HotKey = VK_XBUTTON1;
		break;
	case 1:
		Globals::Aimbot::HotKey = VK_XBUTTON2;
		break;
	case 2:
		Globals::Aimbot::HotKey = VK_RBUTTON;
		break;
	case 3:
		Globals::Aimbot::HotKey = VK_LBUTTON;
		break;
	case 4:
		Globals::Aimbot::HotKey = VK_MENU;
		break;
	}

	switch (Globals::Aimbot::bones)
	{
	case 0:
		Globals::Aimbot::AimHitbox = 8;
	case 1:
		Globals::Aimbot::AimHitbox = 2;
	case 2:
		Globals::Aimbot::AimHitbox = 5;
	}

	if (GetAsyncKeyState(VK_INSERT))
	{
		if (Globals::Menu::menu_key == false)
		{
			Globals::Menu::menu_key = true;
		}
		else if (Globals::Menu::menu_key == true)
		{
			Globals::Menu::menu_key = false;
		}
		Sleep(200);
	}

	if (GetAsyncKeyState(VK_F7))
	{
		if (Globals::Items::showitems == false)
			Globals::Items::showitems = true;
		else
			Globals::Items::showitems = false;
		Sleep(200);
	}
}

void Menu_ImGui()
{
	static int tabb = 0;
	float
		TextSpaceLine = 90.f,
		SpaceLineOne = 120.f,
		SpaceLineTwo = 280.f,
		SpaceLineThr = 420.f;

	static auto flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar;

	ImGui::Begin(XorString("Cxle#0001"), NULL, flags);
	{
		ImGui::SetWindowSize(ImVec2(500, 430), ImGuiCond_Once);
		{
			ImGui::BeginChild(XorString("##Tabs"), ImVec2(100.f, 400.0f));
			{
				ImGui::Spacing();ImGui::Spacing();ImGui::Spacing();
				if (ImGui::Button(("Aimbot"), ImVec2(100, 25)))
				{
					tabb = 0;
				}
				if (ImGui::Button(("Visuals"), ImVec2(100, 25)))
				{
					tabb = 1;
				}
				if (ImGui::Button(("Misc"), ImVec2(100, 25)))
				{
					tabb = 2;
				}
				if (ImGui::Button(("Colors"), ImVec2(100, 25)))
				{
					tabb = 3;
				}
				if (ImGui::Button(("Setts"), ImVec2(100, 25)))
				{
					tabb = 4;
				}

			}
			ImGui::EndChild();
		};

		if (tabb == 0)
		{
			ImGui::SetCursorPos(ImVec2(120, 42));
			ImGui::BeginChild(XorString("##Aimbot"), ImVec2(-1, 370.f));
			{
				ImGui::Checkbox(XorString("Enable Aimbot"), &Globals::Aimbot::aimbot);
				if (Globals::Aimbot::aimbot)
				{
					ImGui::SameLine(SpaceLineOne);
					ImGui::Checkbox(XorString("Draw FOV"), &Globals::Aimbot::drawfov);
					ImGui::SameLine(SpaceLineTwo);
					ImGui::Checkbox(XorString("Smooth"), &Globals::Aimbot::smooth);
					ImGui::PushItemWidth(180.f);
					ImGui::Text(XorString("Aimbot FOV:")); ImGui::SameLine(SpaceLineOne);
					ImGui::SliderFloat(XorString("##aimfov"), &Globals::Aimbot::AimFOV, 1.f, 180.f);

					if (Globals::Aimbot::smooth) {

						ImGui::Text(XorString("Aimbot Smooth:")); ImGui::SameLine(SpaceLineOne);
						ImGui::SliderFloat(XorString("##aimsmooth"), &Globals::Aimbot::AimSpeed, 1.f, 50.f);
					}
					else
					{
						ImGui::Text(XorString("Aimbot Speed:")); ImGui::SameLine(SpaceLineOne);
						ImGui::SliderFloat(XorString("##aimsmoothh"), &Globals::Aimbot::AimSpeed, 1.5f, 5.f);
					}
	
					ImGui::Text(XorString("Aim Key:")); ImGui::SameLine(SpaceLineOne);
					ImGui::Combo(XorString("##HOTKEYS"), &realaimkey, hotkeys, IM_ARRAYSIZE(hotkeys));

					ImGui::Text(XorString("Hitbox:")); ImGui::SameLine(SpaceLineOne);
					ImGui::Combo(XorString("##BONES"), &Globals::Aimbot::bones, Bones, IM_ARRAYSIZE(Bones));
					ImGui::PopItemWidth();
				}
			}

			ImGui::EndChild();
		}
		else if (tabb == 1)
		{
			ImGui::SetCursorPos(ImVec2(120, 42));
			ImGui::BeginChild(XorString("##Players"), ImVec2(-1, 370.f));
			ImGui::PushItemWidth(170.f);
			ImGui::Checkbox(XorString("Show Box"), &Globals::Visuals::box);
			ImGui::SameLine(SpaceLineOne);
			ImGui::Combo(XorString("##BOXSTYLES"), &Globals::Menu::BoxStyles, boxStyle, IM_ARRAYSIZE(boxStyle));

			ImGui::Checkbox(XorString("Show Name"), &Globals::Visuals::name);
			ImGui::SameLine(SpaceLineOne);
			ImGui::Combo(XorString("##NAMESTYLES"), &Globals::Menu::NameMode, nameMode, IM_ARRAYSIZE(nameMode));

			ImGui::Checkbox(XorString("Show Health"), &Globals::Visuals::health);
			ImGui::SameLine(SpaceLineOne);
			ImGui::Combo(XorString("##HEALTHSTYLES"), &Globals::Menu::HealthMode, healthMode, IM_ARRAYSIZE(healthMode));

			ImGui::Checkbox(XorString("Show Shield"), &Globals::Visuals::armor);
			ImGui::SameLine(SpaceLineOne);
			ImGui::Combo(XorString("##ARMORSTYLES"), &Globals::Menu::ShieldMode, healthMode, IM_ARRAYSIZE(healthMode));

			ImGui::Checkbox(XorString("Show Glow"), &Globals::Glow::glowonenemy);
			ImGui::SameLine(SpaceLineOne);
			ImGui::Combo(XorString("##GLOWSTYLES"), &Globals::Glow::GlowMode, glowStyle, IM_ARRAYSIZE(glowStyle));

			ImGui::Checkbox(XorString("Outline"), &Globals::Visuals::outline);
			ImGui::SameLine(90);
			ImGui::Checkbox(XorString("Show Lines"), &Globals::Visuals::lines);
			ImGui::SameLine(205.f);
			ImGui::Checkbox("Show Items (F7)", &Globals::Items::showitems);

			if (Globals::Items::showitems) {

				ImGui::Checkbox(XorString("Meds Items"), &Globals::Items::enable_onlymeds);
				ImGui::SameLine(SpaceLineOne);
				ImGui::Checkbox(XorString("Ammo Items"), &Globals::Items::enable_onlyammo);

				ImGui::Checkbox(XorString("Weapons"), &Globals::Items::enable_onlyguns);
				ImGui::SameLine(SpaceLineOne);
				ImGui::Checkbox(XorString("Shields and Helmets"), &Globals::Items::enable_onlyshields);
			}

			ImGui::Text(XorString("ESP Distance:"));
			ImGui::SameLine(SpaceLineOne);
			ImGui::SliderInt(XorString("##MAXDIS"), &Globals::Visuals::MaxDistance, 0, 800);


			ImGui::Text(XorString("Item Distance:"));
			ImGui::SameLine(SpaceLineOne);
			ImGui::SliderInt(XorString("##MAXDISS"), &Globals::Visuals::MaxItemDistance, 0, 300);


			ImGui::PopItemWidth();
			ImGui::EndChild();
		}

		else if (tabb == 2) //speed
		{
			ImGui::SetCursorPos(ImVec2(120, 42));
			ImGui::BeginChild(XorString("##Chams"), ImVec2(-1, 370.f));
			ImGui::PushItemWidth(180.f);
		

			ImGui::Checkbox(XorString("Enable NoRecoil"), &Globals::Misc::norecoil);
			ImGui::Checkbox(XorString("Custom Crosshair"), &Globals::Misc::cross);


			ImGui::PopItemWidth();
			ImGui::EndChild();
		}

		else if (tabb == 3)
		{
			ImGui::SetCursorPos(ImVec2(120, 42));
			ImGui::BeginChild(XorString("##Colors"), ImVec2(-1, 370.f));


			ImGui::Checkbox(XorString("Overlay FPS"), &Globals::Menu::overlai);
			//ImGui::SameLine(110.f);
//			ImGui::Checkbox("Rainbow", &Globals::Menu::reinbow);
			if (Globals::Menu::reinbow)
			{
				ImGui::Text(XorString("Speed:")); ImGui::SameLine(90.f);
				ImGui::SliderFloat(XorString("##spedasda"), &Globals::Menu::rainbosped, 0.001f, 5.00f);
			}

			if (Globals::Glow::glowonenemy)
			{
				ImGui::Text(XorString("Enemy Glow:"));
				ImGui::SliderFloat(XorString("##COLORCR"), &Globals::Glow::enemyglowR, 0, 10.f);
				ImGui::SliderFloat(XorString("##COLORCG"), &Globals::Glow::enemyglowG, 0, 10.f);
				ImGui::SliderFloat(XorString("##COLORCB"), &Globals::Glow::enemyglowB, 0, 10.f);
				ImGui::Spacing();
				ImGui::Text(XorString("Item Glow:"));
				ImGui::SliderFloat(XorString("##COLOIRCR"), &Globals::Glow::itemglowR, 0, 10.f);
				ImGui::SliderFloat(XorString("##COLOIRCG"), &Globals::Glow::itemglowG, 0, 10.f);
				ImGui::SliderFloat(XorString("##COLOIRCB"), &Globals::Glow::itemglowB, 0, 10.f);
			}

			ImGui::Spacing();

			if (Globals::Visuals::box)
			{
				ImGui::Text(XorString("Box Colors:"));
				ImGui::SliderInt(XorString("##COLORR"), &Color2DR, 0, 255);
				ImGui::SliderInt(XorString("##COLORG"), &Color2DG, 0, 255);
				ImGui::SliderInt(XorString("##COLORB"), &Color2DB, 0, 255);
			}
			ImGui::EndChild();
		}

		else if (tabb == 4)//C:\\Apex-Config1.ini
		{
			ImGui::SetCursorPos(ImVec2(120, 42));
			ImGui::BeginChild(XorString("##Setts"), ImVec2(-1, 370.f));

			if (ImGui::Button((XorString("Save Default")), ImVec2(100, 40)))
			{
				Globals::Settings::Save_Settings("C:\\Apex-Default.ini");
			}
			ImGui::SameLine(SpaceLineOne);
			if (ImGui::Button((XorString("Load Default")), ImVec2(100, 40)))
			{
				Globals::Settings::Load_Settings("C:\\Apex-Default.ini");
			}

			if (ImGui::Button((XorString("Save Config 1")), ImVec2(100, 40)))
			{
				Globals::Settings::Save_Settings("C:\\Apex-Config1.ini");
			}
			ImGui::SameLine(SpaceLineOne);
			if (ImGui::Button((XorString("Load Config 1")), ImVec2(100, 40)))
			{
				Globals::Settings::Load_Settings("C:\\Apex-Config1.ini");
			}

			if (ImGui::Button((XorString("Save Config 2")), ImVec2(100, 40)))
			{
				Globals::Settings::Save_Settings("C:\\Apex-Config2.ini");
			}
			ImGui::SameLine(SpaceLineOne);
			if (ImGui::Button((XorString("Load Config 2")), ImVec2(100, 40)))
			{
				Globals::Settings::Load_Settings("C:\\Apex-Config2.ini");
			}

			ImGui::EndChild();
		}
	}
	ImGui::End();
}