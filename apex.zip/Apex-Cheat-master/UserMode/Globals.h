#pragma once
namespace Globals
{
	enum BONE_ID
	{
		BONE_HEAD,
		BONE_CHEST,
		BONE_STOMACH,
		BONE_HAND,
		BONE_FEET
	};

	namespace Aimbot
	{
		bool aimbot = false;
		bool drawfov = false;
		bool smooth = false;
		float AimFOV = 8.0f;
		float AimSpeed = 3.0f;
		int TargetMode = 0;
		int bones = 0;
		bool NoSwitch = false;
		int AimHitbox = 8;
		uintptr_t EntityBone[] = { /*head*/ 8, /*chest*/ 5, /*stomach*/ 2, /*hand*/ 16,  /*foot*/ 80,};
		bool Hitboxs[7] = { true ,true, false, true };
		Vector3 BesthitPoint;
		DWORD HotKey;
	}

	namespace Glow
	{
		bool glowonenemy = true;
		float enemyglowR = 10.f;
		float enemyglowG = 0.f;
		float enemyglowB = 10.f;
		float itemglowR = 10.f;
		float itemglowG = 0.f;
		float itemglowB = 0.f;
		int GlowMode = 0;
	}

	namespace Visuals
	{
		bool box = false;
		bool name = false;
		bool health = false;
		bool armor = false;
		bool glow = false;
		bool outline = false;
		bool lines = false;
		bool drawhead = false;
		int MaxDistance = 500;
		int MaxItemDistance = 100;
	}

	namespace Misc
	{
		bool norecoil = false;
		bool nospread = false;
		bool cross = false;
	}

	namespace Menu
	{
		bool menu_key = false;
		ImFont* SkeetFont;
		int NameMode = 0;
		int HealthMode = 0;
		int ShieldMode = 0;
		int BoxStyles = 0;
		bool overlai = false;
		bool reinbow = false;
		float rainbosped = 1.00f;
	}

	namespace Items
	{
		bool showitems = true;
		bool enable_itemespshit = false;
		bool enable_onlyattach = false;
		bool enable_onlyguns = false;
		bool enable_onlymeds = false;
		bool enable_onlyshields = false;
		bool enable_onlyammo = false;
	}

	namespace Settings
	{
		BOOL WritePrivateProfileInt(LPCSTR lpAppName, LPCSTR lpKeyName, int nInteger, LPCSTR lpFileName) {
			char lpString[1024];
			sprintf(lpString, "%d", nInteger);
			return WritePrivateProfileStringA(lpAppName, lpKeyName, lpString, lpFileName);
		}

		BOOL WritePrivateProfileFloat(LPCSTR lpAppName, LPCSTR lpKeyName, float nInteger, LPCSTR lpFileName) {
			char lpString[1024];
			sprintf(lpString, "%f", nInteger);
			return WritePrivateProfileStringA(lpAppName, lpKeyName, lpString, lpFileName);
		}

		float GetPrivateProfileFloat(LPCSTR lpAppName, LPCSTR lpKeyName, FLOAT flDefault, LPCSTR lpFileName)
		{
			char szData[32];

			GetPrivateProfileStringA(lpAppName, lpKeyName, std::to_string(flDefault).c_str(), szData, 32, lpFileName);

			return (float)atof(szData);
		}

		void Save_Settings(LPCSTR path)
		{
			WritePrivateProfileInt("Visuals", "Box2D", Globals::Visuals::box, path);
			WritePrivateProfileInt("Visuals", "BoxStyle", Globals::Menu::BoxStyles, path);
			WritePrivateProfileInt("Visuals", "HeadPos", Globals::Visuals::drawhead, path);
			WritePrivateProfileInt("Visuals", "ShowName", Globals::Visuals::name, path);
			WritePrivateProfileInt("Visuals", "Healthbar", Globals::Visuals::health, path);
			WritePrivateProfileInt("Visuals", "LinesEsp", Globals::Visuals::lines, path);
			WritePrivateProfileInt("Visuals", "Outline", Globals::Visuals::outline, path);
			WritePrivateProfileInt("Visuals", "Shield", Globals::Visuals::armor, path);
			WritePrivateProfileInt("Visuals", "HealthMode", Globals::Menu::HealthMode, path);
			WritePrivateProfileInt("Visuals", "ShieldMode", Globals::Menu::ShieldMode, path);
			WritePrivateProfileInt("Visuals", "NameMode", Globals::Menu::NameMode, path);
			WritePrivateProfileInt("Visuals", "MaxDistance", Globals::Visuals::MaxDistance, path);

			WritePrivateProfileInt("Items", "ShowItems", Globals::Items::showitems, path);
			WritePrivateProfileInt("Items", "ShowAmmo", Globals::Items::enable_onlyammo, path);
			WritePrivateProfileInt("Items", "ShowWeapons", Globals::Items::enable_onlyguns, path);
			WritePrivateProfileInt("Items", "ShowMeds", Globals::Items::enable_onlymeds, path);
			WritePrivateProfileInt("Items", "ShowShield", Globals::Items::enable_onlyshields, path);
			WritePrivateProfileInt("Items", "MaxItemDistance", Globals::Visuals::MaxItemDistance, path);

			WritePrivateProfileInt("Glow", "Glow", Globals::Glow::glowonenemy, path);
			WritePrivateProfileInt("Glow", "GlowMode", Globals::Glow::GlowMode, path);

			WritePrivateProfileInt("Aimbot", "DrawFov", Globals::Aimbot::drawfov, path);
			WritePrivateProfileInt("Aimbot", "Aimbot", Globals::Aimbot::aimbot, path);
			WritePrivateProfileInt("Aimbot", "Smooth", Globals::Aimbot::smooth, path);
			WritePrivateProfileFloat("Aimbot", "AimFOV", Globals::Aimbot::AimFOV, path);
			WritePrivateProfileFloat("Aimbot", "AimSpeedValue", Globals::Aimbot::AimSpeed, path);
			WritePrivateProfileInt("Aimbot", "Hitbox", Globals::Aimbot::bones, path);
			WritePrivateProfileInt("Aimbot", "AimKey", realaimkey, path);

			WritePrivateProfileInt("Colors", "2DBoxColorR", Color2DR, path);
			WritePrivateProfileInt("Colors", "2DBoxColorG", Color2DG, path);
			WritePrivateProfileInt("Colors", "2DBoxColorB", Color2DB, path);
			WritePrivateProfileFloat("Colors", "GlowR", Globals::Glow::enemyglowR, path);
			WritePrivateProfileFloat("Colors", "GlowG", Globals::Glow::enemyglowG, path);
			WritePrivateProfileFloat("Colors", "GlowB", Globals::Glow::enemyglowB, path);
			WritePrivateProfileFloat("Colors", "ItemGR", Globals::Glow::itemglowR, path);
			WritePrivateProfileFloat("Colors", "ItemGG", Globals::Glow::itemglowG, path);
			WritePrivateProfileFloat("Colors", "ItemGB", Globals::Glow::itemglowB, path);
			WritePrivateProfileInt("Colors", "LinesR", Globals::Menu::overlai, path);

			WritePrivateProfileInt("Accuracy", "NoRecoil", Globals::Misc::norecoil, path);
			WritePrivateProfileInt("Accuracy", "Spread", Globals::Misc::nospread, path);
			WritePrivateProfileInt("Accuracy", "CustomCross", Globals::Misc::cross, path);

		}

		void Load_Settings(LPCSTR path)
		{
			Globals::Visuals::box = GetPrivateProfileIntA("Visuals", "Box2D", Globals::Visuals::box, path);
			Globals::Menu::BoxStyles = GetPrivateProfileIntA("Visuals", "BoxStyle", Globals::Menu::BoxStyles, path);
			Globals::Visuals::armor = GetPrivateProfileIntA("Visuals", "Shield", Globals::Visuals::armor, path);
			Globals::Visuals::health = GetPrivateProfileIntA("Visuals", "Healthbar", Globals::Visuals::health, path);
			Globals::Visuals::drawhead = GetPrivateProfileIntA("Visuals", "HeadPos", Globals::Visuals::drawhead, path);
			Globals::Visuals::name = GetPrivateProfileIntA("Visuals", "ShowName", Globals::Visuals::name, path);
			Globals::Visuals::outline = GetPrivateProfileIntA("Visuals", "Outline", Globals::Visuals::outline, path);
			Globals::Visuals::lines = GetPrivateProfileIntA("Visuals", "LinesEsp", Globals::Visuals::lines, path);
			Globals::Menu::HealthMode = GetPrivateProfileIntA("Visuals", "HealthMode", Globals::Menu::HealthMode, path);
			Globals::Menu::ShieldMode = GetPrivateProfileIntA("Visuals", "ShieldMode", Globals::Menu::ShieldMode, path);
			Globals::Menu::NameMode = GetPrivateProfileIntA("Visuals", "NameMode", Globals::Menu::NameMode, path);
			Globals::Visuals::MaxDistance = GetPrivateProfileIntA("Visuals", "MaxDistance", Globals::Visuals::MaxDistance, path);

			Globals::Items::showitems = GetPrivateProfileIntA("Items", "ShowItems", Globals::Items::showitems, path);
			Globals::Items::enable_onlyammo = GetPrivateProfileIntA("Items", "ShowAmmo", Globals::Items::enable_onlyammo, path);
			Globals::Items::enable_onlyguns = GetPrivateProfileIntA("Items", "ShowWeapons", Globals::Items::enable_onlyguns, path);
			Globals::Items::enable_onlymeds = GetPrivateProfileIntA("Items", "ShowMeds", Globals::Items::enable_onlymeds, path);
			Globals::Items::enable_onlyshields = GetPrivateProfileIntA("Items", "ShowShield", Globals::Items::enable_onlyshields, path);
			Globals::Visuals::MaxItemDistance = GetPrivateProfileIntA("Items", "MaxItemDistance", Globals::Visuals::MaxItemDistance, path);

			Globals::Glow::glowonenemy = GetPrivateProfileIntA("Glow", "Glow", Globals::Glow::glowonenemy, path);
			Globals::Glow::GlowMode = GetPrivateProfileIntA("Glow", "GlowMode", Globals::Glow::GlowMode, path);

			Globals::Aimbot::drawfov = GetPrivateProfileIntA("Aimbot", "DrawFov", Globals::Aimbot::drawfov, path);
			Globals::Aimbot::aimbot = GetPrivateProfileIntA("Aimbot", "Aimbot", Globals::Aimbot::aimbot, path);
			Globals::Aimbot::smooth = GetPrivateProfileIntA("Aimbot", "Smooth", Globals::Aimbot::smooth, path);
			Globals::Aimbot::AimFOV = GetPrivateProfileFloat("Aimbot", "AimFOV", Globals::Aimbot::AimFOV, path);
			Globals::Aimbot::AimSpeed = GetPrivateProfileFloat("Aimbot", "AimSpeedValue", Globals::Aimbot::AimSpeed, path);
			realaimkey = GetPrivateProfileIntA("Aimbot", "AimKey", realaimkey, path);
			Globals::Aimbot::bones = GetPrivateProfileIntA("Aimbot", "Hitbox", Globals::Aimbot::bones, path);

			Color2DR = GetPrivateProfileIntA("Colors", "2DBoxColorR", Color2DR, path);
			Color2DG = GetPrivateProfileIntA("Colors", "2DBoxColorG", Color2DG, path);
			Color2DB = GetPrivateProfileIntA("Colors", "2DBoxColorB", Color2DB, path);
			Globals::Glow::enemyglowR = GetPrivateProfileFloat("Colors", "GlowR", Globals::Glow::enemyglowR, path);
			Globals::Glow::enemyglowG = GetPrivateProfileFloat("Colors", "GlowG", Globals::Glow::enemyglowG, path);
			Globals::Glow::enemyglowB = GetPrivateProfileFloat("Colors", "GlowB", Globals::Glow::enemyglowB, path);
			Globals::Glow::itemglowR = GetPrivateProfileFloat("Colors", "ItemGR", Globals::Glow::itemglowR, path);
			Globals::Glow::itemglowG = GetPrivateProfileFloat("Colors", "ItemGG", Globals::Glow::itemglowG, path);
			Globals::Glow::itemglowB = GetPrivateProfileFloat("Colors", "ItemGB", Globals::Glow::itemglowB, path);
			Globals::Menu::overlai = GetPrivateProfileIntA("Colors", "LinesR", Globals::Menu::overlai, path);

			Globals::Misc::norecoil = GetPrivateProfileIntA("Accuracy", "NoRecoil", Globals::Misc::norecoil, path);
			Globals::Misc::nospread = GetPrivateProfileIntA("Accuracy", "Spread", Globals::Misc::nospread, path);
			Globals::Misc::cross = GetPrivateProfileIntA("Accuracy", "CustomCross", Globals::Misc::cross, path);

		};
	}
}