#include "Menu.h"
#include <random>

UCHAR szFileSys[255], szVolNameBuff[255];
DWORD dwMFL, dwSysFlags;
DWORD dwSerial;
LPCTSTR szHD = "C:\\";
HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

ImFont* pFont;
ImFont* TabFont;
float EnemyBoxColor[3] = { 1.00f, 0.00f, 0.00f };
ImU32 ColorEnemyBox;
ImFont* tabfont;

DWORD ScreenCenterX;
DWORD ScreenCenterY;

HRESULT DirectXInit(HWND hWnd)
{
	if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &p_Object)))
		exit(3);

	ZeroMemory(&p_Params, sizeof(p_Params));
	p_Params.Windowed = TRUE;
	p_Params.SwapEffect = D3DSWAPEFFECT_DISCARD;
	p_Params.hDeviceWindow = hWnd;
	p_Params.MultiSampleQuality = D3DMULTISAMPLE_NONE;
	p_Params.BackBufferFormat = D3DFMT_A8R8G8B8;
	p_Params.BackBufferWidth = Width;
	p_Params.BackBufferHeight = Height;
	p_Params.EnableAutoDepthStencil = TRUE;
	p_Params.AutoDepthStencilFormat = D3DFMT_D16;

	if (FAILED(p_Object->CreateDeviceEx(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &p_Params, 0, &p_Device)))
	{
		p_Object->Release();
		exit(4);
	}

	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();

	ImFontConfig font_config;
	font_config.OversampleH = 1;
	font_config.OversampleV = 1;
	font_config.PixelSnapH = true;

	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF,
		0x0400, 0x044F,
		0,
	};

	//pFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\comic.ttf", 16.f);
	//TabFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\cherryfont.ttf", 15.f);
	pFont = io.Fonts->AddFontFromFileTTF(XorString("C:\\Windows\\Fonts\\verdana.ttf"), 14.f);

	tabfont = io.Fonts->AddFontFromFileTTF((XorString("C:\\Windows\\Fonts\\cherryfont.ttf")), 32);
	Globals::Menu::SkeetFont = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(skeet_compressed_data, skeet_compressed_size, 25.f, &font_config, ranges);
	
	ImGui_ImplWin32_Init(hWnd);
	ImGui_ImplDX9_Init(p_Device);//settings for ImGUI

	ImGui::StyleColorsClassic();
	ImGuiStyle* style = &ImGui::GetStyle();
	style->WindowPadding = ImVec2(15, 15);
	style->WindowRounding = 0.0f;
	style->FramePadding = ImVec2(2, 2);
	style->FrameRounding = 0.0f;
	style->ItemSpacing = ImVec2(12, 8);
	style->ItemInnerSpacing = ImVec2(8, 6);
	style->IndentSpacing = 25.0f;
	style->ScrollbarSize = 15.0f;
	style->ScrollbarRounding = 0.0f;
	style->GrabMinSize = 5.0f;
	style->GrabRounding = 0.0f;
	style->TabRounding = 0.f;
	style->ChildRounding = 0.f;

	style->Colors[ImGuiCol_Text] = ImVec4(0.80f, 0.80f, 0.83f, 1.00f);
	style->Colors[ImGuiCol_TextDisabled] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style->Colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_ChildWindowBg] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_PopupBg] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
	style->Colors[ImGuiCol_Border] = ImVec4(0.80f, 0.80f, 0.83f, 0.00f);
	style->Colors[ImGuiCol_BorderShadow] = ImVec4(0.92f, 0.91f, 0.88f, 0.00f);
	style->Colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style->Colors[ImGuiCol_FrameBgActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(1.00f, 0.98f, 0.95f, 0.75f);
	style->Colors[ImGuiCol_TitleBgActive] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
	style->Colors[ImGuiCol_MenuBarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
	style->Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_CheckMark] = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
	style->Colors[ImGuiCol_SliderGrab] = ImVec4(1.00f, 0.00f, 0.00f, 0.80f);
	style->Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_Button] = ImColor(18, 18, 18, 255);
	style->Colors[ImGuiCol_ButtonHovered] = ImColor(35, 35, 35, 255);
	style->Colors[ImGuiCol_ButtonActive] = ImColor(60, 60, 60, 255);
	style->Colors[ImGuiCol_Header] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_HeaderHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_HeaderActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_Column] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_ColumnHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style->Colors[ImGuiCol_ColumnActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_ResizeGrip] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style->Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_PlotLines] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
	style->Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
	style->Colors[ImGuiCol_PlotHistogram] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
	style->Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
	style->Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.25f, 1.00f, 0.00f, 0.43f);
	style->Colors[ImGuiCol_ModalWindowDarkening] = ImVec4(1.00f, 0.98f, 0.95f, 0.73f);

	style->WindowTitleAlign.x = 0.50f;
	style->FrameRounding = 2.0f;

	p_Object->Release();
	return S_OK;
}

void create_console()
{
	if (!AllocConsole())
	{
		char buffer[1024] = { 0 };
		sprintf_s(buffer, xorstr_("Failed to AllocConsole( ), GetLastError( ) = %d"), GetLastError());
		MessageBox(HWND_DESKTOP, LPCSTR(buffer), "Error", MB_OK);

		return;
	}

	auto lStdHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	auto hConHandle = _open_osfhandle(PtrToUlong(lStdHandle), _O_TEXT);
	auto fp = _fdopen(hConHandle, xorstr_("w"));

	freopen_s(&fp, xorstr_("CONOUT$"), xorstr_("w"), stdout);

	*stdout = *fp;
	setvbuf(stdout, NULL, _IONBF, 0);
}

void SaveCPU(int ms)
{
	return std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

void SetupWindow()
{
	CreateThread(0, 0, (LPTHREAD_START_ROUTINE)SetWindowToTarget, 0, 0, 0);

	WNDCLASSEX wClass =
	{
		sizeof(WNDCLASSEX),
		0,
		WinProc,
		0,
		0,
		nullptr,
		LoadIcon(nullptr, IDI_APPLICATION),
		LoadCursor(nullptr, IDC_ARROW),
		nullptr,
		nullptr,
		opatudobem.c_str(),
		LoadIcon(nullptr, IDI_APPLICATION)
	};

	if (!RegisterClassEx(&wClass))
		exit(1);

	GameWnd = FindWindow(xorstr_("Respawn001"),0);

	if (GameWnd)    //Loads Up Menu From Menu.hs
	{
		GetClientRect(GameWnd, &GameRect);
		POINT xy;
		ClientToScreen(GameWnd, &xy);
		GameRect.left = xy.x;
		GameRect.top = xy.y;

		Width = GameRect.right;
		Height = GameRect.bottom;
	}

	MyWnd = CreateWindowEx(NULL, M_Name, M_Name, WS_POPUP | WS_VISIBLE, GameRect.left, GameRect.top, Width, Height, NULL, NULL, 0, NULL);
	DwmExtendFrameIntoClientArea(MyWnd, &Margin);
	SetWindowLong(MyWnd, GWL_EXSTYLE, WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW);
	SetWindowDisplayAffinity(MyWnd, WDA_MONITOR);
	ShowWindow(MyWnd, SW_SHOW);
	UpdateWindow(MyWnd);

}

void Draw_ESP()
{
	//DrawCircle(NormalHead.x, NormalHead.y, BoxHeight / 7, &Col.white_, 30);
	//DrawString(14, ScreenHead.x, ScreenHead.y - 5, &Col.white_, true, true, cName);
	//DoAimbot();
	for (int i = 0; i < 100; i++)
	{
		DWORD64 LocalPlayer = GetLocalPlayer();

		DWORD64 Entity = GetEntityByID(i);
		DWORD64 EntityHandle = read<DWORD64>(Entity + 0x518);
		DWORD64 EntityName = read<DWORD64>(EntityHandle);
		std::string PlayerName = GetPlayerName(Entity);

		Vector3 LocalPosition = GetEntityBasePosition(Entity);
		Vector3 MyLocalPosition = GetEntityBasePosition(LocalPlayer);
		Vector3 HeadPosition = GetBodyById(Entity, 8);
		Vector3 ScreenFeet, ScreenHead, NormalHead;

		int health = read<int>(Entity + OFFSET_HEALTH);
		int armor = read<int>(Entity + OFFSET_SHIELD);

		int NewDistance = GetDistance(MyLocalPosition.x, MyLocalPosition.y, MyLocalPosition.z, HeadPosition.x, HeadPosition.y, HeadPosition.z);
		int CalcDistance = (int)(NewDistance * 0.01905f);

		if (CalcDistance > Globals::Visuals::MaxDistance)
			continue;
		if (Entity == NULL)
			continue;
		if (health <= 0) 
			continue;
		if (Entity == LocalPlayer)
			continue;
		if (EntityName == 0x0000726579616c70 && IsSameTeam(Entity))
			continue;

		if (EntityName == 0x0000726579616c70)
		{
			if (world2screen(LocalPosition, ScreenFeet) && world2screen(Vector3(GetBodyById(Entity, 8).x, GetBodyById(Entity, 8).y, GetBodyById(Entity, 8).z + 12.0), ScreenHead) && world2screen(HeadPosition, NormalHead))
			{
				int isalive = read<int>(Entity + OFFSET_BLEED);

				if (isalive == 0)
				{
					AimLoop(Entity);

					int G = (255 * health / 101);
					int R = 0 - G;
					RGBA healthcol = { R, G, 0, 255 };
					RGBA Cor2DBox = { Color2DR, Color2DG, Color2DB ,255 };

					float BoxHeight = ScreenFeet.y - ScreenHead.y;
					float BoxWidth = BoxHeight / 1.7f;

					if (Globals::Visuals::name) {
						if (PlayerName == "")
							PlayerName = XorString("Player");
						if (Globals::Menu::NameMode == 1)
						{
							char cName[300];
							sprintf(cName, XorString("%s"), PlayerName.c_str());
							DrawString(14, ScreenHead.x, ScreenHead.y - 5, &Col.white_, true, true, cName);
						}

						if (Globals::Menu::NameMode == 2)
						{
							char cName[300];
							sprintf(cName, XorString("[%dm]"), CalcDistance);
							DrawString(14, ScreenHead.x, ScreenHead.y - 5, &Col.white_, true, true, cName);
						}

						if (Globals::Menu::NameMode == 3)
						{
							char cName[300];
							sprintf(cName, XorString("[%dm] %s"), CalcDistance, PlayerName.c_str());
							DrawString(14, ScreenHead.x, ScreenHead.y - 5, &Col.white_, true, true, cName);
						}
					}

					if (Globals::Visuals::health)
					{
						if (Globals::Menu::HealthMode == 1 || Globals::Menu::HealthMode == 3) {
							if (health <= 100 && health >= 80)
								DrawFilledRect(ScreenFeet.x - (BoxWidth / 2) - 5, ScreenHead.y, 1, (BoxHeight)* health / 101, &Col.greens);
							else if (health <= 79)
								DrawFilledRect(ScreenFeet.x - (BoxWidth / 2) - 5, ScreenHead.y, 1, (BoxHeight)* health / 101, &healthcol);
						}

						if (Globals::Menu::HealthMode == 2 || Globals::Menu::HealthMode == 3)
						{
							if (CalcDistance <= 200)
							{
								char vida[64];
								sprintf_s(vida, XorString("Health: %d"), (int)health);
								if (health <= 100 || health >= 80)
									DrawString(12, ScreenFeet.x, ScreenFeet.y + 15, &Col.green_, true, true, vida);
								if (health <= 79)
									DrawString(12, ScreenFeet.x, ScreenFeet.y + 15, &healthcol, true, true, vida);
							}
						}
					}


					if (Globals::Visuals::armor)
					{
						if (Globals::Menu::ShieldMode == 1 || Globals::Menu::ShieldMode == 3) {
							if (armor <= 50)
								DrawFilledRect(ScreenFeet.x - 10 - (BoxWidth / 2), ScreenHead.y, 1, (BoxHeight)* armor / 100, &Col.silverwhite_);
							if (armor > 50 && armor <= 75)
								DrawFilledRect(ScreenFeet.x - 10 - (BoxWidth / 2), ScreenHead.y, 1, (BoxHeight)* armor / 100, &Col.blue);
							if (armor > 75 && armor <= 100)
								DrawFilledRect(ScreenFeet.x - 10 - (BoxWidth / 2), ScreenHead.y, 1, (BoxHeight)* armor / 100, &Col.purple);
						}

						if (Globals::Menu::ShieldMode == 2 || Globals::Menu::ShieldMode == 3)
						{
							if (CalcDistance <= 200)
							{
								char armorxd[64];
								sprintf_s(armorxd, XorString("Armor: %d"), (int)armor);
								if (armor <= 50)
									DrawString(12, ScreenFeet.x - 10, ScreenFeet.y + 25, &Col.silverwhite_, true, true, armorxd);
								if (armor > 50 && armor <= 75)
									DrawString(12, ScreenFeet.x - 10, ScreenFeet.y + 25, &Col.blue, true, true, armorxd);
								if (armor > 75 && armor <= 100)
									DrawString(12, ScreenFeet.x - 10, ScreenFeet.y + 25, &Col.purple, true, true, armorxd);
							}
						}
					}

					if (Globals::Visuals::box)
					{
						if (Globals::Menu::BoxStyles == 1)
						{
							if (Globals::Visuals::outline)
							{
								DrawNormalBox(ScreenFeet.x - BoxWidth / 2 + 1, ScreenHead.y, BoxWidth, BoxHeight, 1, &Col.black);
								DrawNormalBox(ScreenFeet.x - BoxWidth / 2 - 1, ScreenHead.y, BoxWidth, BoxHeight, 1, &Col.black);
								DrawNormalBox(ScreenFeet.x - BoxWidth / 2, ScreenHead.y + 1, BoxWidth, BoxHeight, 1, &Col.black);
								DrawNormalBox(ScreenFeet.x - BoxWidth / 2, ScreenHead.y - 1, BoxWidth, BoxHeight, 1, &Col.black);
							}

							DrawNormalBox(ScreenFeet.x - (BoxWidth / 2), ScreenHead.y, BoxWidth, BoxHeight, 1, &Cor2DBox);
						}

						if (Globals::Menu::BoxStyles == 2)
						{
							if (Globals::Visuals::outline)
							{
								DrawCornerBox(ScreenFeet.x - BoxWidth / 2 + 1, ScreenHead.y, BoxWidth, BoxHeight, 2, &Col.black);
								DrawCornerBox(ScreenFeet.x - BoxWidth / 2 - 1, ScreenHead.y, BoxWidth, BoxHeight, 2, &Col.black);
								DrawCornerBox(ScreenFeet.x - BoxWidth / 2, ScreenHead.y + 1, BoxWidth, BoxHeight, 2, &Col.black);
								DrawCornerBox(ScreenFeet.x - BoxWidth / 2, ScreenHead.y - 1, BoxWidth, BoxHeight, 2, &Col.black);
							}

							DrawCornerBox(ScreenFeet.x - (BoxWidth / 2), ScreenHead.y, BoxWidth, BoxHeight, 2, &Cor2DBox);
						}

						if (Globals::Visuals::drawhead)
							DrawCircle(NormalHead.x, NormalHead.y, BoxHeight / 7, &Col.white_, 30);


						if (Globals::Visuals::lines)
							DrawLine((Width / 2), Height, ScreenFeet.x, ScreenFeet.y, &Cor2DBox, 2);
					}
				}
				else if (isalive == 2)
				{
					float BoxHeight = ScreenFeet.y - ScreenHead.y;
					float BoxWidth = BoxHeight / 1.7f;
					DrawNormalBox(ScreenFeet.x - (BoxWidth / 2), ScreenHead.y, BoxWidth, BoxHeight, 1, &Col.red);
					DrawString(14, ScreenHead.x, ScreenHead.y - 5, &Col.red, true, true, XorString("Knocked Out"));
				}
			}
		}

		if (Globals::Misc::norecoil)
			NoRecoil();

		if (Globals::Aimbot::drawfov) {
			DrawCircle(Width / 2, Height / 2, Globals::Aimbot::AimFOV * 8, &Col.white_, 100);
		}

		if (Globals::Misc::cross) {
			DrawFilledRect(Width / 2 - 22, Height / 2, 44, 1, &Col.yellow);
			DrawFilledRect(Width / 2, Height / 2 - 22, 1, 44, &Col.yellow);
		}

		if (Globals::Glow::glowonenemy) {
			if (Globals::Glow::GlowMode == 1 || Globals::Glow::GlowMode == 3)
			GlowEsp(Entity, Globals::Glow::enemyglowR, Globals::Glow::enemyglowG, Globals::Glow::enemyglowB);
		}
	}
	DoAimbot();
}

DWORD WINAPI item_thread(LPVOID)
{
	while (TRUE)
	{
		if (GameisOpen())//Checks If Game Is Open and If Driver Is Mapped
		{
			for (int i = 0; i < 8000; i++)
			{
				LocalPlayer = getLocalPlayer();
				DWORD64 Entity = GetEntityByID(i);

				if (Entity == NULL) {
				}
				else
				{
					DWORD64 EntityHandle = read<uint64_t>(Entity + 0x518);
					DWORD64 EntityName = read<uint64_t>(EntityHandle);

					if (EntityName == 0x7275735f706f7270) {
						if (Globals::Glow::glowonenemy){
							if (Globals::Glow::GlowMode == 1 || Globals::Glow::GlowMode == 3)
							glowItem(Entity, Globals::Glow::itemglowR, Globals::Glow::itemglowG, Globals::Glow::itemglowB);
						}

					}
				}
			}
		}

		SaveCPU(800);
	}
}

void ItemESPScanner()
{
	if (!Globals::Items::showitems)
		return;

	int index = 0;
	for (int i = 0; i < 8000; i++)
	{
		if (!Globals::Items::showitems)
			continue;

		DWORD64 Entity = GetEntityByID(i);
		DWORD64 EntityHandle = read<DWORD64>(Entity + 0x518);
		DWORD64 EntityName = read<DWORD64>(EntityHandle);

		if (EntityName == 0x7275735f706f7270)
		{
			Item temp;
			temp.base = Entity;
			ItemCache1[index] = temp;
			index++;
		}
	}
}

void DrawEspItems()
{
	int index = 0;

	if (!Globals::Items::showitems)
		return;

	for (int i = 0; i < 8000; i++)
	{
		if (!Globals::Items::showitems)
			continue;

		Item temp = ItemCache1[i];
		if (temp.base == 0) continue;

		temp.Id = read<uint32_t>(temp.base + OFFSET_ITEMID);
		Vector3 LocalPosition = GetEntityBasePosition(GetLocalPlayer());
		temp.Origin = GetEntityBasePosition(temp.base);
		if (world2screen(temp.Origin, temp.Screen))
		{
			temp.distance = LocalPosition.DistTo(temp.Origin) / 100;
			//int CalcDistance = (int)(NewDistance * 0.01905f);
			//int CalcDistance = (int)(temp.distance * 0.01905f);
			//temp.distance = (temp.Origin - LocalPosition).Length() / 100;
			if (temp.Id > -1 && temp.Id < 105)
			{
				RGBA item_color = { 255, 255, 255, 255 };
				std::string name = ItemsNameList[temp.Id];

				if (Globals::Items::enable_onlyshields)
				{
					if (name == "Shield 4") item_color = Col.yellow;
					if (name == "Shield 3") item_color = Col.purple;
					if (name == "Shield 2") item_color = Col.blue;
					if (name == "Shield 1") item_color = Col.white_;

					if (name == "Helmet 4") item_color = Col.yellow;
					if (name == "Helmet 3") item_color = Col.purple;
					if (name == "Helmet 2") item_color = Col.blue;
					if (name == "Helmet 1") item_color = Col.white_;

					if (name == "Backpack 4") item_color = Col.yellow;
					if (name == "Backpack 3") item_color = Col.purple;
					if (name == "Backpack 2") item_color = Col.blue;
					if (name == "Backpack 1") item_color = Col.white_;
				}
				else
				{
					if (name == "Shield 4") continue;
					if (name == "Shield 3") continue;
					if (name == "Shield 2") continue;
					if (name == "Shield 1") continue;

					if (name == "Helmet 4") continue;;
					if (name == "Helmet 3") continue;
					if (name == "Helmet 2") continue;
					if (name == "Helmet 1") continue;

					if (name == "Backpack 4") continue;
					if (name == "Backpack 3") continue;
					if (name == "Backpack 2") continue;
					if (name == "Backpack 1") continue;
				}

				if (Globals::Items::enable_onlyammo)
				{
					if (name == "Energy Ammo") item_color = Col.graygreen_;
					if (name == "Shotgun Ammo") item_color = Col.purplered;
					if (name == "Heavy Ammo") item_color = Col.green;
					if (name == "Light Ammo") item_color = Col.yellow;
					if (name == "Sniper Ammo") item_color = Col.blue_;
				}
				else
				{
					if (name == "Energy Ammo") continue;
					if (name == "Shotgun Ammo") continue;
					if (name == "Heavy Ammo") continue;
					if (name == "Light Ammo") continue;
					if (name == "Sniper Ammo") continue;
				}

				if (Globals::Items::enable_onlymeds)
				{
					if (name == "Ultimate Accelerant" ||
						name == "Phoenix Kit" ||
						name == "Med Kit" ||
						name == "Seringle" ||
						name == "Shield Battery" ||
						name == "Shield Cell") item_color = Col.green;
				}
				else
				{
					if (name == "Ultimate Accelerant" ||
						name == "Phoenix Kit" ||
						name == "Med Kit" ||
						name == "Seringle" ||
						name == "Shield Battery" ||
						name == "Shield Cell") continue;
				}

				if (Globals::Items::enable_onlyguns)
				{
					if (name == "Kraber" ||
						name == "Mastiff" ||
						name == "Lstar" ||
						name == "Havoc" ||
						name == "Gold Havoc" ||
						name == "Devotion" ||
						name == "Unknown 1" ||
						name == "Triple Take" ||
						name == "Gold Triple Take" ||
						name == "Flatline" ||
						name == "Gold Flatline" ||
						name == "Hemlock" ||
						name == "G7 Scout" ||
						name == "Gold G7 Scout" ||
						name == "Alternatand" ||
						name == "Gold Alternatand" ||
						name == "R-99" ||
						name == "Prowler" ||
						name == "Gold Prowler" ||
						name == "Longbow" ||
						name == "Gold Longbow" ||
						name == "Charge Rifle" ||
						name == "Gold Charge Rifle" ||
						name == "Spitfire" ||
						name == "R-301" ||
						name == "Eva 8 Auto" ||
						name == "Unknown 2" ||
						name == "Unknown 3" ||
						name == "Peacekeeper" ||
						name == "Gold Peacekeeper" ||
						name == "Gold Mozambique" ||
						name == "Wingman" ||
						name == "Gold Wingman" ||
						name == "RE-45" ||
						name == "VK-47" ||
						name == "Sentinel" ||
						name == "Gold RE-45") item_color = Col.red;
				}
				else
				{
					if (name == "Kraber" ||
						name == "Mastiff" ||
						name == "Lstar" ||
						name == "Havoc" ||
						name == "Gold Havoc" ||
						name == "Devotion" ||
						name == "Unknown 1" ||
						name == "Triple Take" ||
						name == "Gold Triple Take" ||
						name == "Flatline" ||
						name == "Gold Flatline" ||
						name == "Hemlock" ||
						name == "G7 Scout" ||
						name == "Gold G7 Scout" ||
						name == "Alternatand" ||
						name == "Gold Alternatand" ||
						name == "R-99" ||
						name == "Prowler" ||
						name == "Gold Prowler" ||
						name == "Longbow" ||
						name == "Gold Longbow" ||
						name == "Charge Rifle" ||
						name == "Gold Charge Rifle" ||
						name == "Spitfire" ||
						name == "R-301" ||
						name == "Eva 8 Auto" ||
						name == "Unknown 2" ||
						name == "Unknown 3" ||
						name == "Peacekeeper" ||
						name == "Gold Peacekeeper" ||
						name == "Gold Mozambique" ||
						name == "Wingman" ||
						name == "Gold Wingman" ||
						name == "RE-45" ||
						name == "VK-47" ||
						name == "Sentinel" ||
						name == "Gold RE-45") continue;
				}

				if (Globals::Items::enable_onlyattach)
				{
					if (name == "HCOG Classic" ||
						name == "HCOG Bruiser" ||
						name == "Holo" ||
						name == "Variable Holo" ||
						name == "Digital Threat" ||
						name == "HCOG Ranger" ||
						name == "Variable AOG" ||
						name == "Sniper 6x" ||
						name == "Variable Sniper" ||
						name == "Energy Mag 1" ||
						name == "Energy Mag 2" ||
						name == "Energy Mag 3" ||
						name == "Light Mag 1" ||
						name == "Light Mag 2" ||
						name == "Light Mag 3" ||
						name == "Heavy Mag 1" ||
						name == "Heavy Mag 2" ||
						name == "Heavy Mag 3" ||
						name == "Digital Sniper Threat") item_color = Col.darkblue_;
				}
				else
				{
					if (name == "HCOG Classic" ||
						name == "HCOG Bruiser" ||
						name == "Holo" ||
						name == "Variable Holo" ||
						name == "Digital Threat" ||
						name == "HCOG Ranger" ||
						name == "Variable AOG" ||
						name == "Sniper 6x" ||
						name == "Variable Sniper" ||
						name == "Energy Mag 1" ||
						name == "Energy Mag 2" ||
						name == "Energy Mag 3" ||
						name == "Light Mag 1" ||
						name == "Light Mag 2" ||
						name == "Light Mag 3" ||
						name == "Heavy Mag 1" ||
						name == "Heavy Mag 2" ||
						name == "Heavy Mag 3" ||
						name == "Digital Sniper Threat") continue;
				}

				if (name == "Thermite Grenade" ||
					name == "Frag Grenade" ||
					name == "Choke" ||
					name == "KO Shield 1" ||
					name == "KO Shield 2" ||
					name == "KO Shield 3" ||
					name == "KO Shield 4" ||
					name == "P2020" ||
					name == "Mozambique" ||
					name == "Gold P2020" ||
					name == "Sniper Stock" ||
					name == "Sniper Stock 1" ||
					name == "Sniper Stock 2" ||
					name == "Sniper Stock 3" ||
					name == "Standard Stock 1" ||
					name == "Standard Stock 2" ||
					name == "Standard Stock 3" ||
					name == "Shotgun Bolt 1" ||
					name == "Shotgun Bolt 2" ||
					name == "Shotgun Bolt 3" ||
					name == "Selectfire Receiver" ||
					name == "Turbocharger" ||
					name == "Alternator" ||
					name == "Hammerpoint Rounds" ||
					name == "Shuriken") continue;

				if (name == "Barrel Stab 4") continue;
				if (name == "Barrel Stab 3") continue;
				if (name == "Barrel Stab 2") continue;
				if (name == "Barrel Stab 1") continue;

				if (temp.distance > Globals::Visuals::MaxItemDistance)
					continue;

				char itemsxd[100];
				sprintf_s(itemsxd, "[%0.fm] %s", temp.distance, name.c_str());

				//DrawStrokeText2(temp.Screen.x, temp.Screen.y, &item_color, name);
				DrawString(13, temp.Screen.x, temp.Screen.y, &item_color, true, true, itemsxd);

			}

			ItemCache2[index] = temp;
			index++;
		}
	}
}


DWORD WINAPI itemesp_thread(LPVOID)
{
	while (TRUE)
	{
		if (GameisOpen())
		{
			ItemESPScanner();
		}

		SaveCPU(800);
	}
}

void background()
{
	ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Once);
	ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Once);

	ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.09f, 0.09f, 0.09f, 0.40f / 1.f * 2.f));
	static const auto flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoMove;
	ImGui::Begin(XorString("##background"), nullptr, flags);
	ImGui::End();
	ImGui::PopStyleColor();
}

void render() {

	ImGui_ImplDX9_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	shortcurts();
	Draw_ESP();
	DrawEspItems();

	if (Globals::Menu::menu_key) {
		Menu_ImGui();
		background();
		ImGui::GetIO().MouseDrawCursor = 1;
	}
	else
	{
		ImGui::GetIO().MouseDrawCursor = 0;
	}


	char lol[64];
	char ent[64];
	char ents[64];

	char fpsinfo[64];
	sprintf(fpsinfo, XorString("Overlay FPS: %0.f"), ImGui::GetIO().Framerate);

	if (Globals::Menu::overlai)
		DrawStrokeText(30, 44, &Col.red, fpsinfo);
	
	//sprintf(lol, xorstr_("Dukkzin [Press Insert]"), ImGui::GetIO().Framerate);
	//DrawStrokeText(50, 60, &Col.skyblue, lol);

	ImGui::EndFrame();
	p_Device->SetRenderState(D3DRS_ZENABLE, false);
	p_Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	p_Device->SetRenderState(D3DRS_SCISSORTESTENABLE, false);
	p_Device->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);
	if (p_Device->BeginScene() >= 0)
	{
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
		p_Device->EndScene();
	}
	HRESULT result = p_Device->Present(NULL, NULL, NULL, NULL);

	if (result == D3DERR_DEVICELOST && p_Device->TestCooperativeLevel() == D3DERR_DEVICENOTRESET)
	{
		ImGui_ImplDX9_InvalidateDeviceObjects();
		p_Device->Reset(&p_Params);
		ImGui_ImplDX9_CreateDeviceObjects();
	}
}

std::string random_string()
{
	std::string str(XorString("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"));

	std::random_device rd;
	std::mt19937 generator(rd());

	std::shuffle(str.begin(), str.end(), generator);

	return str.substr(0, 27);    // assumes 32 < number of characters in str         
}

std::string RandomString(int len)
{
	srand(time(0));
	std::string str = (XorString("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"));
	std::string newstr;
	int pos;
	while (newstr.size() != len) {
		pos = ((rand() % (str.size() - 1)));
		newstr += str.substr(pos, 1);
	}
	return newstr;
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	create_console();
	HWND ConsWind = GetConsoleWindow();
	comcalma = random_string();
	opatudobem = RandomString(23);
	SetConsoleTitle(comcalma.c_str());

	HANDLE  hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	int col = 12;
	SetConsoleTextAttribute(hConsole, 9);

	CreateThread(NULL, 0, item_thread, NULL, NULL, NULL);
	CreateThread(NULL, 0, itemesp_thread, NULL, NULL, NULL);

	Globals::Settings::Load_Settings("C:\\Apex-Default.ini");
	while (TRUE)
	{
		if (!GameisOpen())
		{
			SetConsoleTextAttribute(hConsole, 12);
			std::cout << XorString("[+] Waiting for the game open") << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(4));
			continue;
		}
		else
		{
			SetConsoleTextAttribute(hConsole, 10);
			std::cout << XorString("[+] Game Found!") << std::endl;
			SetupWindow();
			DirectXInit(MyWnd);
			MainLoop();
		}
	}

	return 0;
}


WPARAM MainLoop()
{
	static RECT old_rc;
	ZeroMemory(&Message, sizeof(MSG));

	while (Message.message != WM_QUIT)
	{
		if (PeekMessage(&Message, MyWnd, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}

		HWND hwnd_active = GetForegroundWindow();
		if (GetAsyncKeyState(0x23) & 1)
			exit(8);

		if (hwnd_active == GameWnd) {
			HWND hwndtest = GetWindow(hwnd_active, GW_HWNDPREV);
			SetWindowPos(MyWnd, hwndtest, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		}
		RECT rc;
		POINT xy;

		ZeroMemory(&rc, sizeof(RECT));
		ZeroMemory(&xy, sizeof(POINT));
		GetClientRect(GameWnd, &rc);
		ClientToScreen(GameWnd, &xy);
		rc.left = xy.x;
		rc.top = xy.y;

		ImGuiIO& io = ImGui::GetIO();
		io.ImeWindowHandle = GameWnd;
		io.DeltaTime = 1.0f / 60.0f;

		POINT p;
		GetCursorPos(&p);
		io.MousePos.x = p.x - xy.x;
		io.MousePos.y = p.y - xy.y;

		if (GetAsyncKeyState(VK_LBUTTON)) {
			io.MouseDown[0] = true;
			io.MouseClicked[0] = true;
			io.MouseClickedPos[0].x = io.MousePos.x;
			io.MouseClickedPos[0].x = io.MousePos.y;
		}
		else
			io.MouseDown[0] = false;

		if (rc.left != old_rc.left || rc.right != old_rc.right || rc.top != old_rc.top || rc.bottom != old_rc.bottom)
		{

			old_rc = rc;

			Width = rc.right;
			Height = rc.bottom;

			p_Params.BackBufferWidth = Width;
			p_Params.BackBufferHeight = Height;
			SetWindowPos(MyWnd, (HWND)0, xy.x, xy.y, Width, Height, SWP_NOREDRAW);
			p_Device->Reset(&p_Params);
		}
		render();

	}
	ImGui_ImplDX9_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	CleanuoD3D();
	DestroyWindow(MyWnd);

	return Message.wParam;
}
LRESULT CALLBACK WinProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, Message, wParam, lParam))
		return true;

	switch (Message)
	{
	case WM_DESTROY:
		CleanuoD3D();
		PostQuitMessage(0);
		exit(4);
		break;
	case WM_SIZE:
		if (p_Device != NULL && wParam != SIZE_MINIMIZED)
		{
			ImGui_ImplDX9_InvalidateDeviceObjects();
			p_Params.BackBufferWidth = LOWORD(lParam);
			p_Params.BackBufferHeight = HIWORD(lParam);
			HRESULT hr = p_Device->Reset(&p_Params);
			if (hr == D3DERR_INVALIDCALL)
				IM_ASSERT(0);
			ImGui_ImplDX9_CreateDeviceObjects();
		}
		break;
	default:
		return DefWindowProc(hWnd, Message, wParam, lParam);
		break;
	}
	return 0;
}
void CleanuoD3D()
{
	if (p_Device != NULL)
	{
		p_Device->EndScene();
		p_Device->Release();
	}
	if (p_Object != NULL)
	{
		p_Object->Release();
	}
}
int isTopwin()
{
	HWND hWnd = GetForegroundWindow();
	if (hWnd == GameWnd)
		return TopWindowGame;
	if (hWnd == MyWnd)
		return TopWindowMvoe;

	return 0;
}
void SetWindowToTarget()
{
	while (true)
	{
		GameWnd = FindWindow(XorString("Respawn001"),0);

		if (!GameWnd)
			continue;
		else
		{
			ZeroMemory(&GameRect, sizeof(GameRect));
			GetWindowRect(GameWnd, &GameRect);
			Width = GameRect.right - GameRect.left;
			Height = GameRect.bottom - GameRect.top;
			DWORD dwStyle = GetWindowLong(GameWnd, GWL_STYLE);
			if (dwStyle & WS_BORDER)
			{
				GameRect.top += 32;
				Height -= 39;
			}
			ScreenCenterX = Width / 2;
			ScreenCenterY = Height / 2;
			MoveWindow(MyWnd, GameRect.left, GameRect.top, Width, Height, true);
		}
	}
}
