#include "stdafx.h"
#include <ntstatus.h>
#include <ntddk.h>
#include <wdm.h>

#define IO_READ_REQUEST  CTL_CODE(FILE_DEVICE_UNKNOWN, 5, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define IO_WRITE_REQUEST CTL_CODE(FILE_DEVICE_UNKNOWN, 6, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)


typedef struct info_t {
	int pid;
	DWORD_PTR address;
	void* value;
	SIZE_T size;
	void* data;
}info, * p_info;

INT64(NTAPI *EnumerateDebuggingDevicesOriginal)(PVOID, PVOID);

PMMVAD(*MiAllocateVad)(UINT_PTR start, UINT_PTR end, LOGICAL deletable);
NTSTATUS(*MiInsertVadCharges)(PMMVAD vad, PEPROCESS process);
VOID(*MiInsertVad)(PMMVAD vad, PEPROCESS process);

INT64 NTAPI EnumerateDebuggingDevicesHook(PREQUEST_DATA data, PINT64 status) {
	if (ExGetPreviousMode() != UserMode || !data) {
		return EnumerateDebuggingDevicesOriginal(data, status);
	}

	// Can't use inline SEH for safe dereferences cause PG
	REQUEST_DATA safeData = { 0 };
	if (!SafeCopy(&safeData, data, sizeof(safeData)) || safeData.Unique != DATA_UNIQUE) {
		return EnumerateDebuggingDevicesOriginal(data, status);
	}
	
	switch (safeData.Type) {
		HANDLE_REQUEST(Extend, REQUEST_EXTEND);
		HANDLE_REQUEST(Write, REQUEST_WRITE);
		HANDLE_REQUEST(Read, REQUEST_READ);
		HANDLE_REQUEST(Protect, REQUEST_PROTECT);
		HANDLE_REQUEST(Alloc, REQUEST_ALLOC);
		HANDLE_REQUEST(Free, REQUEST_FREE);
		HANDLE_REQUEST(Module, REQUEST_MODULE);
	}

	*status = STATUS_NOT_IMPLEMENTED;
	return 0;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT driver, PUNICODE_STRING registryPath) {
	UNREFERENCED_PARAMETER(driver);
	UNREFERENCED_PARAMETER(registryPath);


	UNICODE_STRING DriverName, SymbolName;
	PDEVICE_OBJECT pDeviceObj;
	RtlInitUnicodeString(&DriverName, L"\\Device\\2i2WAcuzTFXejk");
	RtlInitUnicodeString(&SymbolName, L"\\DosDevices\\2i2WAcuzTFXejk");
	UNICODE_STRING deviceNameUnicodeString, deviceSymLinkUnicodeString;
	NTSTATUS NtRet2 = IoCreateDevice(driver, 0, &DriverName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &pDeviceObj);
	driver->Flags |= DO_DIRECT_IO;
	driver->Flags &= ~DO_DEVICE_INITIALIZING;
	driver->MajorFunction[IRP_MJ_CREATE] = CreateCall;
	driver->MajorFunction[IRP_MJ_CLOSE] = CloseCall;
	driver->MajorFunction[IRP_MJ_DEVICE_CONTROL] = IoControl;
	driver->DriverUnload = DriverUnload;
	return Main();

}


//IO CONTROL FUNCTION
NTSTATUS IoControl(PDEVICE_OBJECT DeviceObject, PIRP irp)
{

	irp->IoStatus.Status = STATUS_SUCCESS;
	irp->IoStatus.Information = sizeof(info);

	//STACK IS A VARIABLE FROM WHICH WE ARE GRABBING THE CODE REQUEST
	PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(irp);

	//BUFFER HAS THE ADDRESS PROCCESS ID AND THE VALUE TO READ/WRITE
	auto buffer = (p_info)irp->AssociatedIrp.SystemBuffer;
	ULONG code_request = stack->Parameters.DeviceIoControl.IoControlCode;

	//CHECKING IF THE CODE REQUEST IS TO READ
	if(code_request == IO_READ_REQUEST)
	{ 
		//Read Memory
		readmem(buffer->pid, (void*)buffer->address, buffer->value, buffer->size);
		
	}
	//CHECKING IF THE CODE REQUEST IS TO WRITE
	else if (code_request == IO_WRITE_REQUEST)
	{
		//Write Memory
		writemem(buffer->pid, (void*)buffer->address, buffer->value, buffer->size);
	}

	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return irp->IoStatus.Status;
}

NTSTATUS Main() {
	PCHAR base = GetKernelBase();
	if (!base) {
		printf("! failed to get ntoskrnl base !\n");
		return STATUS_FAILED_DRIVER_ENTRY;
	}

	// MiAllocateVad (yes I'm this lazy)
	PBYTE addr = (PBYTE)FindPatternImage(base, "\x41\xB8\x00\x00\x00\x00\x48\x8B\xD6\x49\x8B\xCE\xE8\x00\x00\x00\x00\x48\x8B\xD8", "xx????xxxxxxx????xxx");
	if (!addr) {
		printf("! failed to find MiAllocateVad !\n");
		return STATUS_FAILED_DRIVER_ENTRY;
	}

	*(PVOID *)&MiAllocateVad = RELATIVE_ADDR(addr + 12, 5);

	// MiInsertVadCharges
	addr = FindPatternImage(base, "\xE8\x00\x00\x00\x00\x8B\xF8\x85\xC0\x78\x31", "x????xxxxxx");
	if (!addr) {
		printf("! failed to find MiInsertVadCharges !\n");
		return STATUS_FAILED_DRIVER_ENTRY;
	}

	*(PVOID *)&MiInsertVadCharges = RELATIVE_ADDR(addr, 5);

	// MiInsertVad
	addr = FindPatternImage(base, "\x48\x2B\xD1\x48\xFF\xC0\x48\x03\xC2", "xxxxxxxxx");
	if (!addr) {
		printf("! failed to find MiInsertVad !\n");
		return STATUS_FAILED_DRIVER_ENTRY;
	}

	for (; *addr != 0xE8 || *(addr + 5) != 0x8B; ++addr);
	*(PVOID *)&MiInsertVad = RELATIVE_ADDR(addr, 5);

	// Intended be manually mapped
	addr = FindPatternImage(base, "\x48\x8B\x05\x00\x00\x00\x00\xE8\x00\x00\x00\x00\x8B\xC8\x85\xC0\x78\x40", "xxx????x????xxxxxx");
	if (!addr) {
		printf("! failed to find xKdEnumerateDebuggingDevices  !\n");
		return STATUS_FAILED_DRIVER_ENTRY;
	}

	*(PVOID *)&EnumerateDebuggingDevicesOriginal = InterlockedExchangePointer(RELATIVE_ADDR(addr, 7), (PVOID)EnumerateDebuggingDevicesHook);

	return STATUS_SUCCESS;



}


//DRIVER UNLOAD FUNCTION
VOID DriverUnload(PDRIVER_OBJECT pDriverObject)
{
	UNICODE_STRING DriverName, SymbolName;
	PDEVICE_OBJECT pDeviceObj;

	IoDeleteSymbolicLink(&SymbolName);
	IoDeleteDevice(pDriverObject->DeviceObject);

}

//CREATE CALL FUNCTION CURRENTLY NO USE
NTSTATUS CreateCall(PDEVICE_OBJECT DeviceObject, PIRP irp)
{
	irp->IoStatus.Status = STATUS_SUCCESS;
	irp->IoStatus.Information = 0;

	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;

	
}

//CLOSE CALL FUNCTION CURRENTLY NO USE
NTSTATUS CloseCall(PDEVICE_OBJECT DeviceObject, PIRP irp)
{
	irp->IoStatus.Status = STATUS_SUCCESS;
	irp->IoStatus.Information = 0;

	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}



//Write memmory of process
NTSTATUS writemem(PEPROCESS pid, PVOID sourceaddress, PVOID targetAdress, SIZE_T Size)
{
	PEPROCESS source_process = PsGetCurrentProcessId();

	PEPROCESS target_process = pid;
	SIZE_T Result;

	if (NT_SUCCESS(MmCopyVirtualMemory(source_process, sourceaddress, pid,targetAdress, Size, KernelMode, &Result)))
	{
		return STATUS_SUCCESS;

	}
	else {
		return STATUS_ACCESS_DENIED;
	}
}

//read memmory of process
NTSTATUS readmem(PEPROCESS pid, PVOID sourceaddress, PVOID targetadress, SIZE_T Size)
{
	PEPROCESS sourceprocess = pid;

	PEPROCESS target_process = PsGetCurrentProcessID();
	SIZE_T result;

	if(NT_SUCCESS(MmCopyVirtualMemory(sourceprocess, sourceaddress,target_process,targetadress, Size,KernelMode, &result)))
	{ 
		return STATUS_SUCCESS;
	}
	else {
		return STATUS_ACCESS_DENIED;
	}
}

