#pragma once
#include "includes.h"

float X;
float Y;

namespace GetStructs {
	typedef struct {
		float Pitch;
		float Yaw;
		float Roll;
	} FRotator;

	typedef struct {
		float X, Y, Z;
	} FVector;

	typedef struct {
		FVector Location;
		FRotator Rotation;
		float FOV;
		float OrthoWidth;
		float OrthoNearClipPlane;
		float OrthoFarClipPlane;
		float AspectRatio;
	} FMinimalViewInfo;
}

static nkDraw* Draw = new nkDraw();

static auto Dummy_vTable = new uintptr_t[0x1001];

struct FBox
{
	Vector3  Min;
	Vector3  Max;
	unsigned char IsValid;
	unsigned char UnknownData00[0x3];
};

struct FMinimalViewInfo
{
	Vector3 Loc;
	Vector3 Rot;
	float FOV;
};

struct FMatrix
{
	float M[4][4];
};


namespace Spoofer {
	namespace _SpoofCallInternal {
		extern "C" PVOID RetSpoofStub();

		template <typename Ret, typename... Args>
		inline Ret Wrapper(PVOID shell, Args... args) {
			auto fn = (Ret(*)(Args...))(shell);
			return fn(args...);
		}

		template <std::size_t Argc, typename>
		struct Remapper {
			template<typename Ret, typename First, typename Second, typename Third, typename Fourth, typename... Pack>
			static Ret Call(PVOID shell, PVOID shell_param, First first, Second second, Third third, Fourth fourth, Pack... pack) {
				return Wrapper<Ret, First, Second, Third, Fourth, PVOID, PVOID, Pack...>(shell, first, second, third, fourth, shell_param, nullptr, pack...);
			}
		};

		template <std::size_t Argc>
		struct Remapper<Argc, std::enable_if_t<Argc <= 4>> {
			template<typename Ret, typename First = PVOID, typename Second = PVOID, typename Third = PVOID, typename Fourth = PVOID>
			static Ret Call(PVOID shell, PVOID shell_param, First first = First{}, Second second = Second{}, Third third = Third{}, Fourth fourth = Fourth{}) {
				return Wrapper<Ret, First, Second, Third, Fourth, PVOID, PVOID>(shell, first, second, third, fourth, shell_param, nullptr);
			}
		};
	}

	template <typename Ret, typename... Args>
	Ret SpoofCall(Ret(*fn)(Args...), Args... args) {
		static PVOID trampoline = nullptr;
		if (!trampoline) {
			trampoline = Utilities::FindPattern("\xFF\x27", "xx");
			if (!trampoline) {
				MessageBox(0, L"Failed to find valid trampoline", L"Failure", 0);
				ExitProcess(0);
			}
		}

		struct {
			PVOID Trampoline;
			PVOID Function;
			PVOID Reg;
		} params = {
			trampoline,
			reinterpret_cast<void*>(fn),
		};

		return _SpoofCallInternal::Remapper<sizeof...(Args), void>::template Call<Ret, Args...>(&_SpoofCallInternal::RetSpoofStub, &params, args...);
	}
}


VOID(*FreeInternal)(PVOID) = nullptr;
GObjects* objects = nullptr;
FString(*GetObjectNameInternal)(PVOID) = nullptr;
PVOID(*GetWeaponStats)(PVOID) = nullptr;

////////////////////////////////////////////////////Hook start

namespace Hooking
{
	uintptr_t GetDiscordModuleBase();
	uintptr_t GetSceneAddress();

	short GetAsyncKeyState(const int vKey);

	bool InsertHook(uintptr_t pOriginal, uintptr_t pHookedFunction, uintptr_t pOriginalCall);
	bool RemoveHook(uintptr_t pOriginal);

	bool CreateHook(uintptr_t pOriginal, uintptr_t pHookedFunction, uintptr_t pOriginalCall);
	bool EnableHook(uintptr_t pTarget, bool bIsEnabled);
	bool EnableHookQue();

	std::vector<uintptr_t> pCreatedHooksArray;
}

uintptr_t Hooking::GetDiscordModuleBase()
{
	static uintptr_t discordModuleBase = 0;

	if (!discordModuleBase)
		discordModuleBase = (uintptr_t)GetModuleHandleA("DiscordHook64.dll");

	return discordModuleBase;
}

uintptr_t Hooking::GetSceneAddress()
{
	static uintptr_t presentSceneAdress = 0;

	if (!presentSceneAdress)
		presentSceneAdress = Helper::PatternScan(GetDiscordModuleBase(), ("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC 20 48 8B D9 41 8B F8"));

	return presentSceneAdress;
}

short Hooking::GetAsyncKeyState(const int vKey)
{
	static uintptr_t addrGetAsyncKeyState = NULL;

	if (!addrGetAsyncKeyState)
		addrGetAsyncKeyState = Helper::PatternScan(GetDiscordModuleBase(), ("40 53 48 83 EC 20 8B D9 FF 15 ? ? ? ?"));

	if (!addrGetAsyncKeyState)
		return false;

	using GetAsyncKeyState_t = short(__fastcall*)(int);
	auto fnGetAyncKeyState = (GetAsyncKeyState_t)addrGetAsyncKeyState;

	return Spoofer::SpoofCall(fnGetAyncKeyState, vKey);
}

// Wrapper
bool Hooking::InsertHook(uintptr_t pOriginal, uintptr_t pHookedFunction, uintptr_t pOriginalCall)
{
	bool bAlreadyCreated = false;
	for (auto _Hook : pCreatedHooksArray)
	{
		if (_Hook == pOriginal)
		{
			bAlreadyCreated = true;
			break;
		}
	}

	if (!bAlreadyCreated)
		bAlreadyCreated = CreateHook(pOriginal, pHookedFunction, pOriginalCall);

	if (bAlreadyCreated)
		if (EnableHook(pOriginal, true))
			if (EnableHookQue())
				return true;

	return false;
}

bool Hooking::RemoveHook(uintptr_t pOriginal)
{
	bool bAlreadyCreated = false;
	for (auto _Hook : pCreatedHooksArray)
	{
		if (_Hook == pOriginal)
		{
			bAlreadyCreated = true;
			break;
		}
	}

	if (bAlreadyCreated)
		if (EnableHook(pOriginal, false))
			if (EnableHookQue())
				return true;

	return false;
}

// Internal Calls
bool Hooking::CreateHook(uintptr_t pOriginal, uintptr_t pHookedFunction, uintptr_t pOriginalCall)
{
	static uintptr_t addrCreateHook = NULL;

	if (!addrCreateHook)
		addrCreateHook = Helper::PatternScan(GetDiscordModuleBase(), ("40 53 55 56 57 41 54 41 56 41 57 48 83 EC 60"));

	if (!addrCreateHook)
		return false;

	using CreateHook_t = uint64_t(__fastcall*)(LPVOID, LPVOID, LPVOID*);
	auto fnCreateHook = (CreateHook_t)addrCreateHook;

	return Spoofer::SpoofCall(fnCreateHook, (void*)pOriginal, (void*)pHookedFunction, (void**)pOriginalCall) == 0 ? true : false;
}

bool Hooking::EnableHook(uintptr_t pTarget, bool bIsEnabled)
{
	static uintptr_t addrEnableHook = NULL;

	if (!addrEnableHook)
		addrEnableHook = Helper::PatternScan(GetDiscordModuleBase(), ("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC 20 33 F6 8B FA"));

	if (!addrEnableHook)
		return false;

	using EnableHook_t = uint64_t(__fastcall*)(LPVOID, bool);
	auto fnEnableHook = (EnableHook_t)addrEnableHook;

	return Spoofer::SpoofCall(fnEnableHook, (void*)pTarget, bIsEnabled) == 0 ? true : false;
}

bool Hooking::EnableHookQue()
{
	static uintptr_t addrEnableHookQueu = NULL;

	if (!addrEnableHookQueu)
		addrEnableHookQueu = Helper::PatternScan(GetDiscordModuleBase(), ("48 89 5C 24 ? 48 89 6C 24 ? 48 89 7C 24 ? 41 57"));

	if (!addrEnableHookQueu)
		return false;

	using EnableHookQueu_t = uint64_t(__stdcall*)(VOID);
	auto fnEnableHookQueu = (EnableHookQueu_t)addrEnableHookQueu;

	return Spoofer::SpoofCall(fnEnableHookQueu) == 0 ? true : false;
}

////////////////////////////////////////////////////////////////////////////Hooks End

BOOL IsValid(DWORD64 address)
{
	if (!spoof_call(game_rbx_jmp, IsBadReadPtr, (const void*)address, (UINT_PTR)8)) return TRUE;
	else return FALSE;
}

template<typename T>
T read(DWORD_PTR address, const T& def = T())
{
	if (IsValid(address))
		return *(T*)address;
	else
		return T();
}

#define skCrypt_(str) _xor_(str).c_str()
#define BIT_CHECK(a,b) (!!((a) & (1ULL<<(b))))
PVOID(*ProcessEvent)(PVOID, PVOID, PVOID, PVOID) = nullptr;

PVOID TargetPawn = nullptr;
PVOID boatPawns = nullptr;
PVOID TargetBoat = nullptr;

PVOID LocalPlayerPawn = nullptr;
PVOID LocalPlayerController = nullptr;

uint64_t OFFSET_UOBJECT = NULL;
uint64_t OFFSET_UWORLD = NULL;
uint64_t OFFSET_GETOBJECTNAMES = NULL;
uint64_t OFFSET_GETNAMEBYINDEX = NULL;
uint64_t OFFSET_FNFREE = NULL;

int Actors[2] = { 0,0 };
int Bots[2] = { 0,0 };

nk_context* g_pNkContext;
static ID3D11Device* uDevice;
uint64_t entityx;

Vector3 CamLoc;
Vector3 CamRot;
float GlobalFOV = 80.f;
/// //////////////////////////////////////// esp colors 
nk_color Boss_color = { 255,0,255,255 };
nk_color Bot_color = { 255,165,0,255 };
nk_color Enemy_color = { 255,0,0,255 };
nk_color Team_color = { 0,255,0,255 };
/// ////////////////////////////////////////
uintptr_t OldAimingActor = 0;

static int rapidfire = 0;

HRESULT(*PresentOriginal)(IDXGISwapChain* pthis, UINT syncInterval, UINT flags) = nullptr;

uint64_t base_address;

int Current = 1;
BYTE FreeCamDirection[6] = { 0 };
GetStructs::FVector FreeCamPosition = { 0 };
GetStructs::FRotator FreeCamRotation[6] = { 0 };
GetStructs::FVector PlayerPosition = { 0 };
INT(*GetViewPoint)(PVOID, GetStructs::FMinimalViewInfo*, BYTE) = nullptr;
auto CurrentLocation = FreeCamPosition;
auto CurrentYaw = 0;
auto CurrentPitch = 0;
auto CurrenRoll = 0;
auto OriginalAitstuck = 0;

DWORD_PTR Uworld;
DWORD_PTR LocalPawn;
DWORD_PTR LocalWeapon;
DWORD_PTR PlayerCameraManager;
DWORD_PTR Localplayer;
DWORD_PTR Rootcomp;
DWORD_PTR PawnMesh;
DWORD_PTR PlayerController;
DWORD_PTR Ulevel;
DWORD_PTR Levels;

struct nk_colorf bg;

char buf_1[512];
char buf_2[512];

int LevelsCount;

static FMatrix* myMatrix = new FMatrix();

DWORD_PTR AActors;
int actor_count;

bool GetAimKey()
{
	switch (AimKey)
	{
	case Keys::LButton:
		return Spoofer::SpoofCall(Hooking::GetAsyncKeyState, VK_LBUTTON);
		//return (o_getasynckeystate((DWORD)VK_LBUTTON) & 0x8000);
	case Keys::RButton:
		return Spoofer::SpoofCall(Hooking::GetAsyncKeyState, VK_RBUTTON);
		//return (o_getasynckeystate((DWORD)VK_RBUTTON) & 0x8000);
	case Keys::Alt_Button:
		return Spoofer::SpoofCall(Hooking::GetAsyncKeyState, VK_MENU);
		//return (o_getasynckeystate((DWORD)VK_MENU) & 0x8000);
	case Keys::Shift:
		return Spoofer::SpoofCall(Hooking::GetAsyncKeyState, VK_LSHIFT);
		//return (o_getasynckeystate((DWORD)VK_LSHIFT) & 0x8000);
	default:
		return false;
	}
}

VOID Free(PVOID buffer) {
	FreeInternal(buffer);
}

void FreeObjName(__int64 address)
{
	if (!IsValid(address)) return;

	auto func = reinterpret_cast<__int64(__fastcall*)(__int64 a1)>(OFFSET_FNFREE);

	spoof_call(game_rbx_jmp, func, address);
}

std::string GetObjectName(uintptr_t Object) {
	if (Object == NULL)
		return skCrypt_("");
	auto fGetObjName = reinterpret_cast<FString * (__fastcall*)(FString * name, uintptr_t entity)>(OFFSET_GETOBJECTNAMES);
	FString result;
	fGetObjName(&result, Object);
	if (result.c_str() == NULL)
		return skCrypt_("");
	auto result_str = result.ToString();
	if (result.c_str() != NULL)
		FreeObjName((__int64)result.c_str());
	return result_str;
}

Vector3 GetPawnEyeViewRot(__int64 Entity)
{
	if (!Entity || !read<uintptr_t>(Entity)) return Vector3(0, 0, 0);

	Vector3 out, out_Rot;

	auto GetActorEyesViewPoint = (*(void(__fastcall**)(__int64, Vector3*, Vector3*))(*(uint64_t*)Entity + 0x5F8));
	spoof_call(game_rbx_jmp, GetActorEyesViewPoint, Entity, &out, &out_Rot);

	return out_Rot;
}

bool IsTargetVisible(uintptr_t entity)
{
	if (!entity || !LocalPawn || !LocalWeapon || !PawnMesh || !PlayerController) return false;

	Vector3 tmp = { 0,0,0 };

	auto fLineOfSight = ((BOOL(__fastcall*)(uintptr_t, uintptr_t, Vector3*))(Offsets::fnLineOfSightTo));
	return spoof_call(game_rbx_jmp, fLineOfSight, PlayerController, entity, &tmp);
}

namespace _SpoofCallInternal {
	extern "C" PVOID RetSpoofStub();

	template <typename Ret, typename... Args>
	inline Ret Wrapper(PVOID shell, Args... args) {
		auto fn = (Ret(*)(Args...))(shell);
		return fn(args...);
	}

	template <std::size_t Argc, typename>
	struct Remapper {
		template<typename Ret, typename First, typename Second, typename Third, typename Fourth, typename... Pack>
		static Ret Call(PVOID shell, PVOID shell_param, First first, Second second, Third third, Fourth fourth, Pack... pack) {
			return Wrapper<Ret, First, Second, Third, Fourth, PVOID, PVOID, Pack...>(shell, first, second, third, fourth, shell_param, nullptr, pack...);
		}
	};

	template <std::size_t Argc>
	struct Remapper<Argc, std::enable_if_t<Argc <= 4>> {
		template<typename Ret, typename First = PVOID, typename Second = PVOID, typename Third = PVOID, typename Fourth = PVOID>
		static Ret Call(PVOID shell, PVOID shell_param, First first = First{}, Second second = Second{}, Third third = Third{}, Fourth fourth = Fourth{}) {
			return Wrapper<Ret, First, Second, Third, Fourth, PVOID, PVOID>(shell, first, second, third, fourth, shell_param, nullptr);
		}
	};
}

namespace util
{
	template <typename Ret, typename... Args>
	Ret SpoofCall(Ret(*fn)(Args...), Args... args) {
		static PVOID trampoline = nullptr;
		if (!trampoline) {
			trampoline = Utilities::FindPattern("\xFF\x27", "xx");
			if (!trampoline) {
				MessageBox(0, L"Failed to find valid trampoline", L"Failure", 0);
				ExitProcess(0);
			}
		}

		struct {
			PVOID Trampoline;
			PVOID Function;
			PVOID Reg;
		} params = {
			trampoline,
			reinterpret_cast<void*>(fn),
		};

		return _SpoofCallInternal::Remapper<sizeof...(Args), void>::template Call<Ret, Args...>(&_SpoofCallInternal::RetSpoofStub, &params, args...);
	}

	BOOL(*LineOfSightToInternal)(PVOID PlayerController, PVOID Actor, GetStructs::FVector* ViewPoint) = nullptr;
	BOOLEAN LineOfSightTo(PVOID PlayerController, PVOID Actor, GetStructs::FVector* ViewPoint);

	BOOLEAN LineOfSightTo(PVOID PlayerController, PVOID Actor, GetStructs::FVector* ViewPoint) {
		return SpoofCall(LineOfSightToInternal, PlayerController, Actor, ViewPoint);
	}

	std::wstring GetObjectFirstName(UObject* object) {
		auto internalName = GetObjectNameInternal(object);
		if (!internalName.c_str()) {
			return L"";
		}

		std::wstring name(internalName.c_str());
		FreeObjName((__int64)internalName.c_str());

		return name;
	}


	std::wstring GetObjectName(UObject* object) {
		std::wstring name(L"");
		for (auto i = 0; object; object = object->Outer, ++i) {
			auto internalName = GetObjectNameInternal(object);
			if (!internalName.c_str()) {
				break;
			}

			name = internalName.c_str() + std::wstring(i > 0 ? L"." : L"") + name;
			FreeObjName((__int64)internalName.c_str());
		}

		return name;
	}

	PVOID FindObject(LPCWSTR name) {
		for (auto array : objects->ObjectArray->Objects) {
			auto fuObject = array;
			for (auto i = 0; i < 0x10000 && fuObject->Object; ++i, ++fuObject) {
				auto object = fuObject->Object;
				if (object->ObjectFlags != 0x41) {
					continue;
				}

				if (GetObjectName(object) == name) {
					return object;
				}
			}
		}

		return 0;
	}
}

namespace Explotsw {

	struct {
		GetStructs::FMinimalViewInfo Info;
		float ProjectionMatrix[4][4];
	} view = { 0 };

	GetStructs::FMinimalViewInfo& GetViewInfo() {
		return view.Info;
	}

	GetStructs::FVector* GetPawnRootLocation(PVOID pawn) {
		auto root = ReadPointer(pawn, Offsets::Engine::Actor::RootComponent);
		if (!root) {
			return nullptr;
		}

		return reinterpret_cast<GetStructs::FVector*>(reinterpret_cast<PBYTE>(root) + Offsets::Engine::SceneComponent::RelativeLocation);
	}
}

DWORD rainbowESP(LPVOID) {
	while (1)
	{
		Boss_color = { 255, 53, 10 };
		Bot_color = { 255, 53, 10 }; // red
		Enemy_color = { 255, 53, 10 };

		Sleep(1500);

		Boss_color = { 255, 0, 240 };
		Bot_color = { 255, 0, 240 }; // pink
		Enemy_color = { 255, 0, 240 };;

		Sleep(1500);

		Boss_color = { 251, 255, 0 };
		Bot_color = { 251, 255, 0 }; // yellow
		Enemy_color = { 251, 255, 0 };

		Sleep(1500);

		Boss_color = { 0, 151, 255 };
		Bot_color = { 0, 151, 255 }; // blue
		Enemy_color = { 0, 151, 255 };
	}
}

static bool firstTime = true;

ID3D11Device* pD11Device = nullptr;

ID3D11DeviceContext* pD11DeviceContext = nullptr;

ID3D11RenderTargetView* pD11RenderTargetView = nullptr;

using f_present = HRESULT(__stdcall*)(IDXGISwapChain* pthis, UINT sync_interval, UINT flags);

f_present SwapChain = nullptr;