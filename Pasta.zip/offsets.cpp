
#include "stdafx.h"
#include "Helper.h"
namespace Offsets {
	PVOID* uWorld = 0;
	PVOID LaunchCharacter = 0;
	uintptr_t fnGetBounds = 0;
	uintptr_t fnLineOfSightTo = 0;
	uintptr_t fnGetBoneMatrix = 0;
	uintptr_t fnGetWeaponStats = 0;
	namespace Engine {
		namespace World {
			DWORD OwningGameInstance = 0x188;
			DWORD Levels = 0x148;
			DWORD PersistentLevel = 0x0;
		}
		namespace SceneComponent {
			DWORD RelativeLocation = 0;
			DWORD ComponentVelocity = 0;
		}

		namespace Level {
			DWORD AActors = 0x98;
		}

		namespace GameInstance {
			DWORD LocalPlayers = 0x38;
		}

		namespace Player {
			DWORD PlayerController = 0x30;
		}

		namespace Controller {
			DWORD ControlRotation = 0x280;
			DWORD RemoteViewPitch = 0;
			PVOID SetControlRotation = 0;
			PVOID SetActorHiddenInGame = 0;
		}

		namespace PlayerController {
			DWORD AcknowledgedPawn = 0x298;
			DWORD PlayerCameraManager = 0x2B0;
		}

		namespace Pawn {
			DWORD PlayerState = 0x248;
		}

		namespace PlayerState {
			PVOID GetPlayerName = 0;
		}

		namespace Actor {
			PVOID SetActorHiddenInGame = 0;
			DWORD CustomTimeDilation = 0x098;
			DWORD RootComponent = 0x130;
		}

		namespace Character {
			DWORD Mesh = 0x278;
		}

		namespace StaticMeshComponent {
			DWORD ComponentToWorld = 0x1C0;
			DWORD StaticMesh = 0x420;
		}

		namespace SkinnedMeshComponent {
			DWORD CachedWorldSpaceBounds = 0x5A0;
		}
	}

	namespace FortniteGame {
		namespace FortPawn {
			DWORD bIsDBNO = 0x53A;
			DWORD bIsDying = 0x520;
			DWORD CurrentWeapon = 0x5A0;
		}

		namespace FortPickup {
			DWORD PrimaryPickupItemEntry = 0x290;
		}

		namespace FortItemEntry {
			DWORD ItemDefinition = 0x18;
		}

		namespace FortItemDefinition {
			DWORD DisplayName = 0x70;
			DWORD Tier = 0x54;
		}

		namespace FortPlayerStateAthena {
			DWORD TeamIndex = 0xE68;
		}

		namespace FortWeapon {
			DWORD LastFireTime = 0x8A4;
			DWORD LastFireTimeVerified = 0x8A8;
			DWORD WeaponData = 0x358;
			DWORD LastFireAbilityTime = 0xA98;
		}

		namespace FortWeaponItemDefinition {
			DWORD WeaponStatHandle = 0x7B8;
		}

		namespace FortProjectileAthena {
			DWORD FireStartLoc = 0x868;
		}

		namespace FortBaseWeaponStats {
			//Reload
			DWORD ReloadTime = 0xFC;
		}


		namespace BuildingContainer {
			DWORD bAlreadySearched = 0xC51;
		}
	}

	namespace UI {
		namespace ItemCount {
			DWORD ItemDefinition = 0;
		}
	}

}