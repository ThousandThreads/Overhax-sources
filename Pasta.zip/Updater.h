#include <winnt.h>
#pragma once
VOID init();